#!/bin/bash
# LAN Party launcher for muOS / Knulli "Ports".
# Copy this script and the lanparty/ folder into your Ports folder, and put the host's
# address and your name in lanparty/server.txt (and optionally the online server's address).
#
# On start it fetches every game from the LAN Party Host (only files that are missing or
# changed), then plays whichever game the host is running. When the host switches games,
# it closes the current one and opens the next. Quitting a game (Select + Start) quits this too.

DIR="$(cd "$(dirname "$0")/lanparty" && pwd)"
cd "$DIR" || exit 1
exec >log.txt 2>&1
echo "LAN Party launcher, $(date)"

# If PortMaster is installed, borrow its controller mapping for this device.
for d in /mnt/mmc/MUOS/PortMaster /mnt/sdcard/MUOS/PortMaster /userdata/roms/ports/PortMaster \
         /opt/system/Tools/PortMaster /roms/ports/PortMaster; do
    if [ -f "$d/control.txt" ]; then
        controlfolder="$d"
        # shellcheck disable=SC1091
        source "$d/control.txt"
        get_controls 2>/dev/null
        break
    fi
done

# server.txt: the LAN host's address on the first line (as the host's screen shows it), your
# name on the second, optionally the online server on the third, used when the LAN host
# isn't running, and optionally your age on the fourth (for the games' assists; 12 if not given). Addresses can carry the hub's port, e.g. 192.168.1.20:8000.
if [ ! -f server.txt ]; then
    echo "No server.txt: copy server.txt.example to server.txt and put the host's address in it."
    exit 1
fi
LAN=$(sed -n 1p server.txt | tr -d '\r ')
NAME=$(sed -n 2p server.txt | tr -d '\r')
ONLINE=$(sed -n 3p server.txt | tr -d '\r ' | sed 's|^http://||; s|/$||')
[ -n "$NAME" ] || NAME=$(hostname 2>/dev/null | cut -c1-12)
AGE=$(sed -n 4p server.txt | tr -dc '0-9')

# fetch URL FILE ("-" for stdout), with curl or busybox wget, whichever the firmware has.
fetch() {
    if command -v curl >/dev/null 2>&1; then
        curl -fsS --connect-timeout 5 --max-time "${3:-120}" -o "$2" "$1"
    else
        wget -q -T "${3:-20}" -O "$2" "$1"
    fi
}
with_port() { case "$1" in *:*) echo "$1" ;; ?*) echo "$1:8000" ;; esac; }
use() { HOST=${1%%:*}; HUB="http://$1"; echo "Host $HUB ($2), playing as $NAME"; }

# A LAN party first: the address in server.txt, then any LAN hub the online server saw on
# this internet connection. Otherwise the online server.
HUB=""
if [ -n "$LAN" ] && fetch "http://$(with_port "$LAN")/api/current" /dev/null 4 2>/dev/null; then
    use "$(with_port "$LAN")" lan
elif [ -n "$ONLINE" ]; then
    ONLINE=$(with_port "$ONLINE")
    for h in $(fetch "http://$ONLINE/api/lan?format=text" - 5 2>/dev/null | sed -n 's|^lan http://||p' | tr -d '\r'); do
        fetch "http://$h/api/current" /dev/null 4 2>/dev/null && { use "$h" lan; break; }
    done
    [ -n "$HUB" ] || use "$ONLINE" online
else
    use "$(with_port "$LAN")" lan
fi
# The game to join, e.g. "racer". With our name the host adds "#N" after a Reset from its host
# page ("racer#2"): the value changes, so the loop below closes the game and joins again.
current() { fetch "$HUB/api/current?name=$(printf %s "$NAME" | sed 's/ /%20/g')" - 2>/dev/null | tr -d '\r\n '; }

# Brings games/<id>/ in line with the host's manifest:
#   game <id> <version> <udp port> <title...>
#   file <id> <name> <sha256> <size>
sync_games() {
    local manifest kind id name sha
    manifest=$(fetch "$HUB/api/handheld" -) || { echo "Cannot reach $HUB"; return 1; }
    echo "$manifest" | while read -r kind id name sha _; do
        [ "$kind" = file ] || continue
        mkdir -p "games/$id"
        [ "$(cat "games/$id/.$name.sha256" 2>/dev/null)" = "$sha" ] && [ -f "games/$id/$name" ] && continue
        echo "Downloading $id/$name"
        if ! fetch "$HUB/handheld/$id/$name" "games/$id/$name.part"; then
            echo "  failed"; rm -f "games/$id/$name.part"; continue
        fi
        if command -v sha256sum >/dev/null 2>&1 &&
           [ "$(sha256sum "games/$id/$name.part" | cut -d' ' -f1)" != "$sha" ]; then
            echo "  checksum mismatch, skipped"; rm -f "games/$id/$name.part"; continue
        fi
        mv -f "games/$id/$name.part" "games/$id/$name"
        chmod +x "games/$id/$name"
        echo "$sha" > "games/$id/.$name.sha256"
    done
}

sync_games
tries=0
while true; do
    token=$(current)
    game=${token%%#*}
    if [ -z "$game" ]; then
        # The host is between games (or not reachable yet). Give up after two minutes.
        tries=$((tries + 1))
        [ $tries -gt 60 ] && { echo "No game from $HUB, giving up"; exit 1; }
        sleep 2
        continue
    fi
    tries=0
    [ -x "games/$game/$game" ] || sync_games
    if [ ! -x "games/$game/$game" ]; then
        echo "No $game program for this device"; sleep 5; continue
    fi

    echo "Joining $game"
    # The age goes to games built with assists (an older build would stop at an option it doesn't know).
    agearg=()
    [ -n "$AGE" ] && grep -qa -- "--age N" "games/$game/$game" 2>/dev/null && agearg=(--age "$AGE")
    (cd "games/$game" && exec "./$game" --fullscreen --server "$HOST" --name "$NAME" "${agearg[@]}") &
    pid=$!
    switched=0
    while kill -0 $pid 2>/dev/null; do
        sleep 2
        now=$(current)
        if [ -n "$now" ] && [ "$now" != "$token" ]; then
            if [ "${now%%#*}" = "$game" ]; then echo "Reset from the host page"; else echo "Host switched to ${now%%#*}"; fi
            switched=1
            kill $pid 2>/dev/null
            for _ in 1 2 3 4 5; do kill -0 $pid 2>/dev/null || break; sleep 1; done
            kill -9 $pid 2>/dev/null
            break
        fi
    done
    wait $pid 2>/dev/null
    [ $switched = 1 ] || { echo "Game closed, bye"; break; }
done
