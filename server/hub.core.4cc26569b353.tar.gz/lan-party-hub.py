#!/usr/bin/env python3
"""LAN Party Host: runs one LAN Party game at a time and rotates between them.

Every player device talks to this one program:
  - browsers open http://<host>:8000 (spectator first, then the game),
  - handhelds fetch their game files from /api/handheld and join the game it names,
  - the host's screen shows the running game's own spectator view.

The games themselves are unchanged. Each one is started as `<game> --host`, and the hub
reads its log lines to know who is playing and when a race, match or round has ended,
so it can switch games between rounds rather than in the middle of one.

Two modes, same games:
  - LAN (default): the host PC's screen shows the spectator and the announcer plays. It answers
    LAN discovery probes on udp/47799 and, if given --online-server, checks in with the online
    server so devices on the same internet connection get pointed here instead.
  - --online: a server on the internet. Game hosts run --headless, no announcer, host controls
    need --admin-key, and /api/lan tells each device about LAN hubs that checked in from its address.

Python 3 standard library only, so it runs on a stock Bazzite install.
"""
import argparse
import hashlib
import hmac
import json
import os
import random
import re
import select
import signal
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from announcer import Announcer
from updater import RESTART_CODE, Updater

HERE = os.path.dirname(os.path.abspath(__file__))

# Log lines every game host prints (see each game's src/net.cpp).
JOIN_RE = re.compile(r"host: (.*?) joined from .*?( \(spectator\))?$")
LEAVE_RE = re.compile(r"host: (.*) (left|timed out)$")
# The engine's events (engine-template/src/events.h): what the game has, its plan, and what is on.
EVENTS_RE = re.compile(r"events: (kinds|plan|start|end) ?(.*)$")
# The age-based assists a game host gave a player (DIFFICULTY.md in racer-prototype/).
ASSIST_RE = re.compile(r"host: (.*?) is (\d+)(?: \(no age given\))?, assists (\d+)%$")
READY_RE = re.compile(r"host: listening on udp/")

DISCOVERY_PORT = 47799        # LAN clients broadcast "LANPARTY?" here; the hub answers
LAN_CHECKIN_SECONDS = 30      # how often a LAN hub tells the online server it is up
LAN_CHECKIN_TTL = 95          # the online server forgets a LAN hub after this long without news


def log(msg):
    print(time.strftime("%H:%M:%S"), "hub:", msg, flush=True)


class Game:
    def __init__(self, spec, root):
        self.spec = spec
        self.previous = None      # the Game this one replaced in an update (for rollback)
        self.id = spec["id"]
        self.title = spec["title"]
        self.short = spec.get("short", self.id)
        self.binary = os.path.join(root, spec["binary"])
        self.web = os.path.join(root, spec["web"])
        self.handheld = os.path.join(root, spec["handheld"])
        self.udp = spec["udp"]
        self.web_port = spec["web_port"]
        self.logs = spec.get("logs", self.id + "-logs")
        self.round_end = re.compile(spec["round_end"])
        self.host_args = spec.get("host_args", [])
        self.blurb = spec.get("blurb", "")
        self._sums = {}

    def available(self):
        return os.access(self.binary, os.X_OK)

    def sha256(self, path):
        """Checksum of a file, cached until its size or time changes (the PC binary is 4 MB)."""
        st = os.stat(path)
        key = (st.st_size, st.st_mtime)
        if self._sums.get(path, (None,))[0] != key:
            with open(path, "rb") as f:
                self._sums[path] = (key, hashlib.sha256(f.read()).hexdigest())
        return self._sums[path][1]

    def handheld_files(self):
        """[(name, sha256, size)] for every file the handheld needs, plus a version for the set."""
        files = []
        if os.path.isdir(self.handheld):
            for name in sorted(os.listdir(self.handheld)):
                path = os.path.join(self.handheld, name)
                if not os.path.isfile(path) or name.startswith("."):
                    continue
                files.append((name, self.sha256(path), os.path.getsize(path)))
        version = hashlib.sha256("".join(d for _, d, _ in files).encode()).hexdigest()[:16]
        return version, files

    def pc_files(self):
        """The PC client is the host's own binary, so a PC always plays the build the host runs."""
        if not self.available():
            return "", []
        name = os.path.basename(self.binary)
        digest = self.sha256(self.binary)
        return digest[:16], [(name, digest, os.path.getsize(self.binary))]


REDIRECT_PAGE = """<!doctype html><meta charset="utf-8"><title>LAN Party</title>
<p>Taking you to the LAN party&hellip;</p>
<script>location.replace(location.protocol + '//' + location.hostname + ':%d/');</script>
"""


def write_redirect_pages(folder, hub_port):
    """Pages the game's own web server hands out instead of the game: they send the browser to
    the hub. The games show their own port on the lobby screen (e.g. :8080), so people type
    that; landing on the hub instead means they follow the rotation like everyone else."""
    os.makedirs(folder, exist_ok=True)
    for name in ("index.html", "spectator.html"):
        with open(os.path.join(folder, name), "w") as f:
            f.write(REDIRECT_PAGE % hub_port)
    return folder


class PortRedirects:
    """Answers on the web ports of the games that are not running, sending browsers to the hub,
    so an address from a game's lobby screen or an old bookmark still works after a switch."""

    def __init__(self, ports, hub_port):
        self.ports = sorted(set(ports))
        self.hub_port = hub_port
        self.servers = {}
        hub = hub_port

        class Redirect(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def do_GET(self):
                host = (self.headers.get("Host") or "localhost").rsplit(":", 1)[0]
                body = b"LAN Party moved to the hub\n"
                self.send_response(302)
                self.send_header("Location", "http://%s:%d/" % (host, hub))
                self.send_header("Content-Type", "text/plain")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("Connection", "close")
                self.end_headers()
                if self.command != "HEAD":
                    self.wfile.write(body)

            do_HEAD = do_GET

            def log_message(self, *a):
                pass

        self.handler = Redirect

    def set_active(self, port):
        """Frees `port` for the game about to start, and covers every other game port."""
        srv = self.servers.pop(port, None)
        if srv:
            srv.shutdown()
            srv.server_close()
        for p in self.ports:
            if p == port or p in self.servers:
                continue
            try:
                srv = ThreadingHTTPServer(("", p), self.handler)
            except OSError:
                continue  # something else has it; the game's own fallback still works
            srv.daemon_threads = True
            threading.Thread(target=srv.serve_forever, daemon=True).start()
            self.servers[p] = srv


class Rotation:
    """Owns the running game host process and decides when to move to the next game."""

    def __init__(self, games, args):
        self.games = games
        self.order = [g for g in games if g.available()]
        if not self.order:
            sys.exit("hub: no game binaries found; run tools/build-hub.sh first")
        self.args = args
        self.period = args.minutes * 60
        self.grace = args.grace * 60
        self.lock = threading.Condition()
        self.proc = None
        self.redirects = None     # PortRedirects, LAN mode only
        self.current = None       # Game whose host is running (or starting)
        self.ready = False        # its host is listening
        self.started = 0.0        # when it became ready
        self.round_over = 0.0     # last time it reported the end of a round
        self.rounds = 0
        self.people = []          # names of players connected (not spectators)
        self.assists = {}         # name -> assist percent, from the game host's log
        self.watchers = 0
        self.generation = 0       # bumps on every change clients care about
        self.hold = False         # stay on the current game
        self.pending = None       # game picked from the host page, switch now
        self.upcoming = None      # the game after this one, drawn when this one starts
        self.previous = None      # the game before this one
        self.resets = {}          # lower-case player name -> times the host page reset them
        self.stopping = False
        self.handheld_cache = {}
        self.ws_conns = set()
        self.addresses = []
        self.run_id = 0           # bumps every time a game host starts
        self.announcer = None     # host-only voice (announcer.py), set in main()
        self.events = self.no_events()
        self.updater = None       # Updater, when this hub keeps itself up to date
        self.exit_code = 0        # RESTART_CODE after installing a new hub
        self.want = []            # --games, kept so an update keeps the same selection

    # ---- events (the game's plan, and the host page's Start now) -------------
    @staticmethod
    def no_events():
        return {"kinds": [], "plan": [], "running": None, "since": 0.0}

    def event_line(self, kind, rest):
        """One `events: ...` line from the game host (called with the lock held)."""
        ev = self.events
        now = time.time()
        if kind == "kinds":
            ev["kinds"] = [{"id": k.split(":", 1)[0], "title": k.split(":", 1)[-1]} for k in rest.split("|") if k]
        elif kind == "plan":
            plan = []
            for item in rest.split():
                gid, _, secs = item.rpartition("+")
                if gid and secs.isdigit():
                    # +0 is one the host page asked for, waiting for the one on now to end.
                    plan.append({"id": gid, "at": now + int(secs), "asked": secs == "0"})
            ev["plan"] = plan
        elif kind == "start":
            ev["running"] = rest.split()[0] if rest else None
            ev["since"] = now
        elif kind == "end":
            ev["running"] = None
        self.bump()

    def start_event(self, event_id):
        """The host page's Start now: the game host reads `event <id>` on its standard input."""
        with self.lock:
            proc, ok = self.proc, any(k["id"] == event_id for k in self.events["kinds"]) or event_id == "next"
        if not ok or not proc or not proc.stdin:
            return False
        try:
            proc.stdin.write("event %s\n" % event_id)
            proc.stdin.flush()
        except (BrokenPipeError, OSError, ValueError):
            return False
        log("event %s from the host page" % event_id)
        return True

    def events_state(self, now):
        ev = self.events
        titles = {k["id"]: k["title"] for k in ev["kinds"]}
        return {
            "kinds": ev["kinds"],
            "running": {"id": ev["running"], "title": titles.get(ev["running"], ev["running"]),
                        "for": int(now - ev["since"])} if ev["running"] else None,
            "plan": [{"id": p["id"], "title": titles.get(p["id"], p["id"]), "in": max(0, int(p["at"] - now)),
                      "asked": p["asked"]}
                     for p in ev["plan"]],
        }

    # ---- state for clients -------------------------------------------------
    def state(self):
        with self.lock:
            g = self.current
            now = time.time()
            nxt = self.next_game()
            left = None
            if g and self.ready and not self.hold:
                left = max(0, int(self.period - (now - self.started)))
            return {
                "generation": self.generation,
                "game": g.id if g else None,
                "run": self.run_id,
                "title": g.title if g else None,
                "short": g.short if g else None,
                "blurb": g.blurb if g else "",
                "ready": self.ready,
                "players": list(self.people),
                "assists": {n: a for n, a in self.assists.items() if n in self.people},
                "watchers": self.watchers,
                "seconds_left": left,
                "waiting_for_round": left == 0 and len(self.people) > 0,
                "hold": self.hold,
                "rounds": self.rounds,
                "next": {"id": nxt.id, "title": nxt.title, "short": nxt.short} if nxt else None,
                "games": [{"id": x.id, "title": x.title, "short": x.short} for x in self.order],
                "addresses": self.join_urls(),
                "shuffle": not self.args.in_order,
                "resets": dict(self.resets),
                "announcer": bool(self.announcer and self.announcer.enabled),
                "events": self.events_state(now),
                "mode": "online" if self.args.online else "lan",
                # Where a LAN hub's pages carry on if the hub goes away.
                "online_url": "" if self.args.online else self.args.online_server.rstrip("/"),
                # Changes when a GameTboy One benchmark arrives, so the host page fetches /api/bench.
                "bench_rev": Handler.bench.rev if Handler.bench else 0,
                "update": self.updater.state() if self.updater else None,
            }

    def join_urls(self):
        if self.args.public_url:
            return [self.args.public_url]
        return ["http://%s:%d" % (a, self.args.port) for a in self.addresses]

    def bump(self):
        self.generation += 1
        self.lock.notify_all()

    def next_game(self):
        if self.pending:
            return self.pending
        if self.upcoming:
            return self.upcoming
        if not self.current:
            return self.order[0]
        i = self.order.index(self.current) if self.current in self.order else -1
        return self.order[(i + 1) % len(self.order)]

    def draw_upcoming(self, playing):
        """Shuffle mode: pick the next game at random now, so every screen can show what's next.
        Never the same game twice in a row, and not the one before that either when there's choice."""
        if self.args.in_order or len(self.order) < 2:
            self.upcoming = None
            return
        recent = {playing.id}
        if len(self.order) > 2 and self.previous:
            recent.add(self.previous.id)
        self.upcoming = random.choice([g for g in self.order if g.id not in recent])

    def reset_player(self, name):
        """The host page's Reset: that player's browser or handheld reloads the game and joins again."""
        key = name.strip().lower()
        if not key:
            return False
        with self.lock:
            self.resets[key] = self.resets.get(key, 0) + 1
            self.bump()
        log("reset " + name + " from the host page")
        return True

    def pick(self, game_id):
        with self.lock:
            for g in self.order:
                if g.id == game_id:
                    self.pending = g
                    self.bump()
                    return True
        return False

    def set_hold(self, hold):
        with self.lock:
            self.hold = hold
            if not hold and self.ready:
                self.started = time.time() - min(time.time() - self.started, self.period)
            self.bump()

    # ---- the game host process ---------------------------------------------
    def launch(self, game):
        logs = os.path.join(self.args.data, game.logs)
        os.makedirs(logs, exist_ok=True)
        # The game's own web server only hands out pages that send people to the hub; the hub
        # serves the real game pages itself and passes their WebSocket through to the game.
        pages = write_redirect_pages(os.path.join(self.args.data, "redirect", game.id), self.args.port)
        if self.redirects:
            self.redirects.set_active(game.web_port)
        cmd = [game.binary, "--host", "--web", pages, "--web-port", str(game.web_port),
               "--logs", logs] + game.host_args
        if self.args.online:
            cmd.append("--headless")
        elif self.args.fullscreen:
            cmd.append("--fullscreen")
        elif self.args.size:
            cmd += ["--size", self.args.size]
        log("starting " + game.title + ": " + " ".join(cmd))
        if self.announcer:
            self.announcer.game_starting(game.id, first=self.run_id == 0, restart=game is self.current)
        with self.lock:
            if self.current is not game:
                self.previous = self.current
            self.current = game
            self.draw_upcoming(game)
            self.run_id += 1
            self.ready = False
            self.people = []
            self.assists = {}
            self.watchers = 0
            self.round_over = 0.0
            self.rounds = 0
            self.pending = None
            self.events = self.no_events()
            self.bump()
        # Standard input carries the host page's commands to the game ("event cheese").
        self.proc = subprocess.Popen(cmd, cwd=self.args.data, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, stdin=subprocess.PIPE,
                                     text=True, errors="replace", bufsize=1)
        threading.Thread(target=self.read_output, args=(self.proc, game), daemon=True).start()

    def read_output(self, proc, game):
        game_log = open(os.path.join(self.args.data, "host-" + game.id + ".log"), "a")
        for line in proc.stdout:
            line = line.rstrip("\n")
            game_log.write(line + "\n")
            game_log.flush()
            text = line.split("INFO: ", 1)[-1]
            joined = None
            with self.lock:
                if proc is not self.proc:
                    continue
                if READY_RE.search(text) and not self.ready:
                    self.ready = True
                    self.started = time.time()
                    log(game.title + " is up")
                    self.bump()
                elif m := JOIN_RE.search(text):
                    if m.group(2):
                        self.watchers += 1
                    else:
                        self.people.append(m.group(1))
                        joined = m.group(1)
                    self.bump()
                elif m := ASSIST_RE.search(text):
                    self.assists[m.group(1)] = int(m.group(3))
                    self.bump()
                elif m := LEAVE_RE.search(text):
                    if m.group(1) in self.people:
                        self.people.remove(m.group(1))
                    elif self.watchers:
                        self.watchers -= 1
                    self.bump()
                elif m := EVENTS_RE.search(text):
                    self.event_line(m.group(1), m.group(2))
                elif game.round_end.search(text):
                    self.round_over = time.time()
                    self.rounds += 1
                    self.bump()
            if self.announcer:
                self.announcer.host_line(text, joined)
        game_log.close()

    def stop_current(self):
        proc = self.proc
        if not proc:
            return
        with self.lock:
            self.ready = False
            self.bump()
        # Cut browser sockets first so pages notice at once, then end the host.
        for s in list(self.ws_conns):
            try:
                s.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
        proc.send_signal(signal.SIGTERM)
        try:
            proc.wait(5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        self.proc = None

    def should_switch(self):
        """Time to move on: after the period, at the end of a round (or straight away if nobody plays)."""
        if self.pending:
            return "picked on the host page"
        up = self.updater
        if up and up.staged and self.ready:
            if up.force:
                return "Update now on the host page"
            if not self.people:
                return "an update is ready and nobody is playing"
        if self.hold or not self.ready or len(self.order) < 2:
            return None
        played = time.time() - self.started
        if played < self.period:
            return None
        if not self.people:
            return "time is up and nobody is playing"
        if self.round_over >= self.started + self.period:
            return "time is up and the round has ended"
        if played >= self.period + self.grace:
            return "time is up and the round ran over"
        return None

    def run(self):
        first = next((g for g in self.order if g.id == self.args.start), None)
        if not first:
            first = self.order[0] if self.args.in_order else random.choice(self.order)
        self.launch(first)
        crashes = []
        while not self.stopping:
            time.sleep(0.5)
            if self.proc and self.proc.poll() is not None:
                code = self.proc.returncode
                self.proc = None
                # On the host PC, a clean exit means someone closed the game window (or pressed
                # Esc / Select + Start): that's the host quitting, so the hub stops too. Only a
                # crash restarts the game, and not forever. The online server has no window, so
                # any exit there is unexpected.
                if code == 0 and not self.args.online:
                    log(self.current.title + " was closed on this PC, stopping LAN Party Host")
                    self.stopping = True
                    break
                now = time.time()
                crashes = [t for t in crashes if now - t < 120] + [now]
                if len(crashes) > 3 and self.current.previous and self.updater:
                    bad = self.current
                    log("%s keeps crashing since the update (code %s), going back to its previous build"
                        % (bad.title, code))
                    self.updater.revert_game(bad.id, bad.previous.spec)
                    self.swap_games([bad.previous if g is bad else g for g in self.games])
                    crashes = []
                    self.launch(next(g for g in self.order if g.id == bad.id))
                    continue
                if len(crashes) > 3:
                    log(self.current.title + " keeps crashing (code %s), stopping LAN Party Host; see %s"
                        % (code, os.path.join(self.args.data, "host-" + self.current.id + ".log")))
                    self.stopping = True
                    break
                log(self.current.title + " exited with code %s, restarting it" % code)
                time.sleep(2)
                if not self.stopping:
                    self.launch(self.pending or self.current)
                continue
            with self.lock:
                why = self.should_switch()
                nxt = self.next_game() if why else None
            if why:
                log("switching to %s: %s" % (nxt.title, why))
                self.stop_current()
                time.sleep(1)  # let the ports free up
                if self.updater and self.updater.staged:
                    nxt = self.install_update(nxt)
                    if not nxt:
                        break
                self.launch(nxt)
        self.stop_current()

    # ---- updates (updater.py), only ever between games ------------------------
    def install_update(self, nxt):
        """Installs the downloaded update and returns the game to start, or None when the hub
        itself was updated and must restart (it then starts with that game)."""
        try:
            specs, restart = self.updater.apply()
        except Exception as e:  # noqa: BLE001 - a broken update must not stop the party
            log("could not install the update (%s), carrying on with what is installed" % e)
            return nxt
        if restart:
            with open(os.path.join(self.args.data, "resume"), "w") as f:
                f.write(nxt.id + "\n")
            log("the hub itself was updated, restarting it to start %s" % nxt.title)
            self.exit_code = RESTART_CODE
            self.stopping = True
            return None
        if specs:
            old = {g.id: g for g in self.games}
            games = [Game(s, self.updater.root) for s in specs]
            for g in games:
                was = old.get(g.id)
                if was and was.binary != g.binary and was.available():
                    g.previous = was
            if self.want:
                games = [g for w in self.want for g in games if g.id == w]
            if not any(g.available() for g in games):
                log("the update has no playable games, keeping the old ones")
                return nxt
            added = sorted({g.short for g in games} - {g.short for g in self.games})
            self.swap_games(games)
            log("update installed" + (": new " + ", ".join(added) if added else "")
                + "; rotation: " + ", ".join(g.short for g in self.order))
        return next((g for g in self.order if g.id == nxt.id), None) or self.order[0]

    def swap_games(self, games):
        """Puts a new set of Game objects in place, keeping the rotation's place by game id."""
        with self.lock:
            self.games = games
            self.order = [g for g in games if g.available()]
            by_id = {g.id: g for g in self.order}
            self.current = by_id.get(self.current.id) if self.current else None
            self.previous = by_id.get(self.previous.id) if self.previous else None
            self.pending = by_id.get(self.pending.id) if self.pending else None
            self.upcoming = by_id.get(self.upcoming.id) if self.upcoming else None
            self.handheld_cache = {}
            self.bump()
        if self.redirects:
            self.redirects.ports = sorted(set(g.web_port for g in games))


# ---- HTTP ----------------------------------------------------------------------
CONTENT_TYPES = {".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css",
                 ".png": "image/png", ".svg": "image/svg+xml", ".json": "application/json"}


def is_local(addr):
    return addr in ("127.0.0.1", "::1", "::ffff:127.0.0.1")


def same_site(addr):
    """The key LAN hubs and devices are matched on: an IPv4 address, or an IPv6 /64."""
    addr = addr[7:] if addr.startswith("::ffff:") else addr
    if ":" in addr:
        return ":".join(socket.inet_ntop(socket.AF_INET6, socket.inet_pton(socket.AF_INET6, addr)).split(":")[:4])
    return addr


class LanRegistry:
    """Online server only: LAN hubs that checked in, by the internet address they came from.

    A device asking /api/lan from the same address is on the same network (behind the same
    router) as those hubs, so it can be sent to the LAN party instead of playing online."""

    def __init__(self):
        self.lock = threading.Lock()
        self.sites = {}           # same_site(addr) -> {lan url: (seen, game)}

    def checkin(self, addr, urls, game, bye=False):
        now = time.time()
        with self.lock:
            if bye:
                site = self.sites.get(same_site(addr), {})
                for u in urls:
                    site.pop(u, None)
                return
            if len(self.sites) > 5000:
                self.expire(now)
            site = self.sites.setdefault(same_site(addr), {})
            for u in urls[:8]:
                site[u] = (now, game)

    def expire(self, now):
        for key in list(self.sites):
            self.sites[key] = {u: v for u, v in self.sites[key].items() if now - v[0] < LAN_CHECKIN_TTL}
            if not self.sites[key]:
                del self.sites[key]

    def lookup(self, addr):
        now = time.time()
        with self.lock:
            site = self.sites.get(same_site(addr), {})
            return [{"url": u, "game": g} for u, (seen, g) in sorted(site.items(), key=lambda x: -x[1][0])
                    if now - seen < LAN_CHECKIN_TTL]


# What a LAN hub may check in as: a plain IPv4 address or a .local name, never a site elsewhere.
class BenchStore:
    """GameTboy One benchmark results (benchmark/ in the project), newest first.

    Devices POST their JSON to /api/bench/result; each is kept as a file in <data>/bench and the
    newest are shown on the host page. The latest full run from a GameTboy One is also kept as
    <data>/bench/reference/gametboy-one-budget.json (GET /api/bench/reference.json): the budget
    to build games to. Games don't read it themselves."""
    KEEP = 40

    def __init__(self, folder):
        self.folder = folder
        self.lock = threading.Lock()
        self.results = []
        self.rev = 0
        try:
            names = sorted((n for n in os.listdir(folder) if n.endswith(".json")), reverse=True)
        except OSError:
            names = []
        for name in names[:self.KEEP]:
            try:
                with open(os.path.join(folder, name)) as f:
                    self.results.append(json.load(f))
            except (OSError, ValueError):
                pass

    def add(self, result, addr):
        result["id"] = time.strftime("%Y%m%d-%H%M%S") + "-%04x" % random.randrange(0x10000)
        result["received"] = int(time.time())
        result["from"] = addr
        os.makedirs(self.folder, exist_ok=True)
        with open(os.path.join(self.folder, result["id"] + ".json"), "w") as f:
            json.dump(result, f)
        if (result.get("device") or {}).get("name") == "GameTboy One" and result.get("version", 1) >= 2 \
                and not result.get("quick"):
            os.makedirs(os.path.dirname(self.reference_path()), exist_ok=True)
            with open(self.reference_path(), "w") as f:
                json.dump(result, f, indent=1)
        with self.lock:
            self.results.insert(0, result)
            del self.results[self.KEEP:]
            self.rev += 1
        return result["id"]

    def reference_path(self):
        return os.path.join(self.folder, "reference", "gametboy-one-budget.json")

    def reference(self):
        try:
            with open(self.reference_path()) as f:
                return json.load(f)
        except (OSError, ValueError):
            return None


BENCH_BLOCK = os.urandom(1 << 20)   # what /api/bench/download sends, repeated
BENCH_MAX_BYTES = 64 << 20          # the most one benchmark download or upload moves

LAN_URL_RE = re.compile(r"^http://(\d{1,3}(\.\d{1,3}){3}|[A-Za-z0-9-]+\.local):\d{1,5}$")


class Handler(BaseHTTPRequestHandler):
    server_version = "LanPartyHub/1"
    protocol_version = "HTTP/1.1"
    rotation: Rotation = None
    lan_hubs: LanRegistry = None
    bench: BenchStore = None
    web_dir = os.path.join(HERE, "web")

    def setup(self):
        super().setup()
        # Headers and body go out as separate writes; without this, small answers (/ping) wait
        # for the other side's delayed ACK, about 40 ms, which the benchmark would count as wifi lag.
        try:
            self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError:
            pass

    def log_message(self, fmt, *a):
        if self.rotation.args.verbose:
            log("%s %s" % (self.client_ip(), fmt % a))

    def client_ip(self):
        # Behind a reverse proxy (for https), the device's own address is in X-Forwarded-For.
        fwd = self.headers.get("X-Forwarded-For", "") if self.rotation.args.behind_proxy else ""
        return fwd.split(",")[0].strip() or self.client_address[0]

    def is_admin(self, q):
        """May change the rotation: the host PC itself, or anyone with the online server's admin key."""
        key = self.rotation.args.admin_key
        given = self.headers.get("X-Hub-Key") or q.get("key", [""])[0]
        if key and given and hmac.compare_digest(given, key):
            return True
        return is_local(self.client_address[0]) and not self.headers.get("X-Forwarded-For")

    def send_bytes(self, body, ctype, code=200, cache=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache or "no-store")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def send_json(self, obj, code=200):
        self.send_bytes(json.dumps(obj).encode(), "application/json", code)

    def send_text(self, text, code=200):
        self.send_bytes(text.encode(), "text/plain; charset=utf-8", code)

    def send_file(self, path, cache="no-cache"):
        try:
            st = os.stat(path)
        except OSError:
            return self.send_text("not found\n", 404)
        etag = '"%x-%x"' % (int(st.st_mtime), st.st_size)
        if path.endswith(".html"):
            # HTML is rewritten below: a new rewrite must not be answered with a stale 304.
            etag = etag[:-1] + '-' + HTML_REWRITE_VERSION + '"'
        if self.headers.get("If-None-Match") == etag:
            self.send_response(304)
            self.send_header("ETag", etag)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        with open(path, "rb") as f:
            body = f.read()
        if path.endswith(".html"):
            body = hosted_page(body)
        self.send_response(200)
        self.send_header("Content-Type", CONTENT_TYPES.get(os.path.splitext(path)[1], "application/octet-stream"))
        self.send_header("Content-Length", str(len(body)))
        self.send_header("ETag", etag)
        self.send_header("Cache-Control", cache)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def game(self, gid):
        return next((g for g in self.rotation.order if g.id == gid), None)

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        url = urlparse(self.path)
        path = url.path
        q = parse_qs(url.query)
        rot = self.rotation
        if path == "/ws" and self.headers.get("Upgrade", "").lower() == "websocket":
            return self.proxy_websocket()
        if path == "/ping":
            return self.send_text("lan-party hub ok\n")
        if path in ("/", "/index.html"):
            return self.send_file(os.path.join(self.web_dir, "hub.html"))
        if path == "/play":
            return self.send_file(os.path.join(self.web_dir, "play.html"))
        if path == "/host":
            return self.send_file(os.path.join(self.web_dir, "host.html"))
        if path.startswith("/static/"):
            name = os.path.basename(path)
            return self.send_file(os.path.join(self.web_dir, name))
        if path == "/api/state":
            # Long poll: ?since=N waits up to 20 s for something to change.
            since = int(q.get("since", ["-1"])[0] or -1)
            deadline = time.time() + 20
            with rot.lock:
                while rot.generation == since and time.time() < deadline:
                    rot.lock.wait(deadline - time.time())
            st = rot.state()
            st["local"] = self.is_admin(q)
            if st["local"] and not rot.args.online:
                # Shown on the host page, so whoever runs the party can manage it from a phone.
                st["admin_pin"] = rot.args.admin_key
            return self.send_json(st)
        if path == "/api/info":
            # Lets a client tell a LAN hub from the online server before it joins.
            return self.send_json({"lanparty": 1, "mode": "online" if rot.args.online else "lan",
                                   "addresses": rot.join_urls()})
        if path == "/api/lan":
            # LAN hubs on the asking device's own network, best first (online server only).
            hubs = self.lan_hubs.lookup(self.client_ip()) if self.lan_hubs else []
            if q.get("format", [""])[0] == "text":
                return self.send_text("".join("lan %s\n" % h["url"] for h in hubs))
            return self.send_json({"hubs": hubs})
        if path == "/api/pc":
            return self.send_text(self.manifest("pc"))
        if path == "/api/current":
            # For the handheld launcher: the game to join now, empty while switching.
            # With ?name=, a reset from the host page adds "#N" (e.g. "racer#2"): a launcher that
            # sees the value change closes the game and joins again, as it does for a switch.
            name = q.get("name", [""])[0].strip().lower()
            with rot.lock:
                g = rot.current if rot.ready else None
                n = rot.resets.get(name, 0) if name else 0
            return self.send_text((g.id + ("#%d" % n if n else "") if g else "") + "\n")
        if path == "/api/handheld":
            return self.send_text(self.manifest("handheld"))
        if path == "/api/bench":
            # GameTboy One benchmark results, newest first, for the host page.
            with self.bench.lock:
                results = list(self.bench.results)
            ref = self.bench.reference()
            return self.send_json({"rev": self.bench.rev, "results": results,
                                   "reference": ref.get("id") if ref else None})
        if path == "/api/bench/reference.json":
            # The budget games are built to: the latest full run from a GameTboy One.
            ref = self.bench.reference()
            return self.send_json(ref) if ref else self.send_text("no GameTboy One budget yet\n", 404)
        m = re.match(r"^/api/bench/([0-9a-f-]+)\.json$", path)
        if m:
            with self.bench.lock:
                r = next((x for x in self.bench.results if x.get("id") == m.group(1)), None)
            return self.send_json(r) if r else self.send_text("not found\n", 404)
        if path == "/api/bench/download":
            # The benchmark's wifi test: ?bytes=N of random data, as fast as the network takes it.
            try:
                n = max(0, min(int(q.get("bytes", ["0"])[0]), BENCH_MAX_BYTES))
            except ValueError:
                return self.send_text("bad size\n", 400)
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(n))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            if self.command != "HEAD":
                while n > 0:
                    k = min(n, len(BENCH_BLOCK))
                    self.wfile.write(BENCH_BLOCK[:k])
                    n -= k
            return
        m = re.match(r"^/handheld/([a-z0-9-]+)/([A-Za-z0-9._-]+)$", path)
        if m and self.game(m.group(1)):
            return self.send_file(os.path.join(self.game(m.group(1)).handheld, m.group(2)))
        m = re.match(r"^/pc/([a-z0-9-]+)/([A-Za-z0-9._-]+)$", path)
        if m and self.game(m.group(1)) and m.group(2) == os.path.basename(self.game(m.group(1)).binary):
            return self.send_file(self.game(m.group(1)).binary)
        m = re.match(r"^/g/([a-z0-9-]+)/(spectator)?$", path)
        if m and self.game(m.group(1)):
            page = "spectator.html" if m.group(2) else "index.html"
            return self.send_file(os.path.join(self.game(m.group(1)).web, page))
        if path == "/handheld/LAN Party.sh" or path == "/handheld/launcher.sh":
            return self.send_file(os.path.join(HERE, "handheld", "LAN Party.sh"))
        self.send_text("not found\n", 404)

    def do_POST(self):
        url = urlparse(self.path)
        q = parse_qs(url.query)
        if url.path == "/api/lan/checkin":
            return self.lan_checkin()
        if url.path == "/api/bench/upload":
            return self.bench_upload()
        if url.path == "/api/bench/result":
            return self.bench_result()
        if not self.is_admin(q):
            msg = "this needs the admin key" if self.rotation.args.online else "only the host PC can change the rotation"
            return self.send_json({"error": msg}, 403)
        rot = self.rotation
        if url.path == "/api/switch":
            gid = q.get("game", [""])[0]
            if not gid:
                with rot.lock:
                    gid = rot.next_game().id if not rot.pending else rot.pending.id
            if not rot.pick(gid):
                return self.send_json({"error": "no such game"}, 404)
            return self.send_json({"ok": True})
        if url.path == "/api/announcer" and rot.announcer:
            rot.announcer.set_enabled(q.get("on", ["1"])[0] == "1")
            with rot.lock:
                rot.bump()
            return self.send_json({"ok": True})
        if url.path == "/api/reset":
            if not rot.reset_player(q.get("name", [""])[0]):
                return self.send_json({"error": "no name"}, 400)
            return self.send_json({"ok": True})
        if url.path == "/api/event":
            if not rot.start_event(q.get("id", [""])[0]):
                return self.send_json({"error": "this game has no such event"}, 404)
            return self.send_json({"ok": True})
        if url.path == "/api/update":
            if not rot.updater or not rot.updater.url:
                return self.send_json({"error": "updates are off on this hub"}, 404)
            rot.updater.check_now()
            return self.send_json({"ok": True})
        if url.path == "/api/hold":
            rot.set_hold(q.get("on", ["1"])[0] == "1")
            return self.send_json({"ok": True})
        self.send_json({"error": "not found"}, 404)

    def bench_upload(self):
        """The benchmark's wifi test: reads and drops the body, and says how long it took."""
        try:
            n = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            n = -1
        if n < 0 or n > BENCH_MAX_BYTES:
            self.close_connection = True
            return self.send_json({"error": "too big"}, 413)
        t0, left = time.time(), n
        while left > 0:
            chunk = self.rfile.read(min(left, 1 << 16))
            if not chunk:
                self.close_connection = True
                return
            left -= len(chunk)
        return self.send_json({"bytes": n, "seconds": round(time.time() - t0, 3)})

    def bench_result(self):
        """A device's benchmark results (benchmark/src/report.cpp makes them)."""
        try:
            n = int(self.headers.get("Content-Length", "0"))
            if n <= 0 or n > 512 * 1024:
                raise ValueError
            result = json.loads(self.rfile.read(n))
            if not isinstance(result, dict) or result.get("tool") != "gametboy-bench":
                raise ValueError
        except ValueError:
            self.close_connection = True
            return self.send_json({"error": "not a benchmark result"}, 400)
        rid = self.bench.add(result, self.client_ip())
        dev = result.get("device") or {}
        log("benchmark from %s (%s, %s): %s" % (result.get("player") or "?", dev.get("name", "?"),
                                                 self.client_ip(), result.get("headline") or result.get("score")))
        with self.rotation.lock:
            self.rotation.bump()
        return self.send_json({"ok": True, "id": rid})

    def lan_checkin(self):
        """A LAN hub saying it is up: {"urls": ["http://192.168.1.20:8000"], "game": "racer"}."""
        if not self.lan_hubs:
            return self.send_json({"error": "not an online server"}, 404)
        try:
            n = int(self.headers.get("Content-Length", "0"))
            body = json.loads(self.rfile.read(min(n, 4096)) or b"{}")
            urls = [u for u in body.get("urls", []) if isinstance(u, str) and LAN_URL_RE.match(u)]
            game = str(body.get("game") or "")[:32]
        except (ValueError, AttributeError):
            return self.send_json({"error": "bad check-in"}, 400)
        if urls:
            self.lan_hubs.checkin(self.client_ip(), urls, game, bye=bool(body.get("bye")))
        return self.send_json({"ok": True, "seen_as": same_site(self.client_ip())})

    def manifest(self, kind):
        """Plain text so a busybox shell can read it:
            current <game id or empty>
            game <id> <version> <udp port> <title...>   (the program is files/<id>/<id>)
            file <id> <name> <sha256> <size>
        kind is "handheld" (arm64 builds) or "pc" (the host's own x86_64 build)."""
        rot = self.rotation
        with rot.lock:
            cur = rot.current.id if rot.current and rot.ready else ""
        lines = ["lanparty 1", "current " + cur, "mode " + ("online" if rot.args.online else "lan")]
        for g in rot.order:
            version, files = g.handheld_files() if kind == "handheld" else g.pc_files()
            if not files:
                continue
            lines.append("game %s %s %d %s" % (g.id, version, g.udp, g.title))
            for name, digest, size in files:
                lines.append("file %s %s %s %d" % (g.id, name, digest, size))
        return "\n".join(lines) + "\n"

    def proxy_websocket(self):
        """Pass a browser's WebSocket through to the running game's own web server."""
        rot = self.rotation
        with rot.lock:
            g = rot.current if rot.ready else None
        if not g:
            return self.send_text("no game running yet\n", 503)
        try:
            up = socket.create_connection(("127.0.0.1", g.web_port), timeout=3)
        except OSError:
            return self.send_text("game is not answering\n", 502)
        up.settimeout(None)
        head = "%s %s %s\r\n" % (self.command, self.path, self.request_version)
        for k, v in self.headers.items():
            head += "%s: %s\r\n" % (k, v)
        up.sendall((head + "\r\n").encode("latin-1"))
        # The browser sends nothing more until it has the handshake reply, so nothing is
        # left in self.rfile's buffer and the raw sockets can be relayed directly.
        down = self.connection
        rot.ws_conns.add(down)
        try:
            socks = [down, up]
            while True:
                r, _, x = select.select(socks, [], socks, 60)
                if x:
                    break
                done = False
                for s in r:
                    data = s.recv(65536)
                    if not data:
                        done = True
                        break
                    (up if s is down else down).sendall(data)
                if done:
                    break
        except OSError:
            pass
        finally:
            rot.ws_conns.discard(down)
            up.close()
            self.close_connection = True


# Served game pages decide "am I on a hub?" with hosted="http:"===location.protocol and
# otherwise start an offline race against AI cars. Behind an https proxy (Caddy on the online
# server) that check fails, so every browser player got their own private game that the hub
# and its spectator never saw. Any page the hub serves is on a hub, so it is always hosted.
# The games' C++ only accepts a "ws://" server address, so the page keeps ws:// and a small
# shim turns it into wss:// at the WebSocket itself when the page is on https.
HTML_REWRITE_VERSION = "h2"
WSS_SHIM = (b'<script>if(location.protocol=="https:"&&window.WebSocket){(function(W){'
            b'var S=function(u,p){u=String(u).replace(/^ws:/,"wss:");'
            b'return p===undefined?new W(u):new W(u,p)};'
            b'S.prototype=W.prototype;["CONNECTING","OPEN","CLOSING","CLOSED"].forEach('
            b'function(k){S[k]=W[k]});window.WebSocket=S})(window.WebSocket)}</script>')


def hosted_page(body):
    # Undo the older in-file patch (sed on the server) and the older hub rewrite: the game
    # rejects a wss:// address, so the shim does that part now.
    body = body.replace(b'(location.protocol=="https:"?"wss://":"ws://")+location.host', b'"ws://"+location.host')
    body = body.replace(b'"http:"===location.protocol', b'/^https?:$/.test(location.protocol)')
    body = body.replace(b"location.protocol === 'http:'", b"/^https?:$/.test(location.protocol)")
    if b'"ws://"+location.host' in body or b"'ws://' + location.host" in body:
        i = body.find(b"<script")
        if i >= 0:
            body = body[:i] + WSS_SHIM + body[i:]
    return body


def local_addresses():
    addrs = set()
    try:
        out = subprocess.run(["hostname", "-I"], capture_output=True, text=True, timeout=2).stdout
        addrs.update(a for a in out.split() if "." in a)
    except (OSError, subprocess.SubprocessError):
        pass
    if not addrs:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("192.0.2.1", 9))
            addrs.add(s.getsockname()[0])
            s.close()
        except OSError:
            pass
    return sorted(addrs)


def answer_discovery(rot):
    """LAN mode: answer "LANPARTY?" broadcasts with "LANPARTY 1 <tcp port> lan"."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(("", DISCOVERY_PORT))
    except OSError as e:
        log("LAN discovery off (udp/%d: %s); devices can still scan for tcp/%d" % (DISCOVERY_PORT, e, rot.args.port))
        return
    reply = ("LANPARTY 1 %d lan\n" % rot.args.port).encode()
    while not rot.stopping:
        try:
            data, addr = s.recvfrom(64)
            if data.startswith(b"LANPARTY?"):
                s.sendto(reply, addr)
        except OSError:
            time.sleep(1)


def check_in_online(rot, online, bye=False):
    """LAN mode: tell the online server this hub is up, so devices on this network that ask it
    (browsers above all, which can't search the network) get sent here instead. With bye, say
    it is closing, so nobody is sent to it any more."""
    url = online.rstrip("/") + "/api/lan/checkin"
    if bye:
        body = json.dumps({"urls": rot.join_urls(), "bye": True}).encode()
        try:
            urllib.request.urlopen(urllib.request.Request(url, body, {"Content-Type": "application/json"}), timeout=3).close()
        except OSError:
            pass
        return
    said = None
    while not rot.stopping:
        rot.addresses = local_addresses() or rot.addresses
        with rot.lock:
            game = rot.current.id if rot.current else ""
        body = json.dumps({"urls": rot.join_urls(), "game": game}).encode()
        try:
            req = urllib.request.Request(url, body, {"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=10) as r:
                ok = "checked in with the online server as " + json.load(r).get("seen_as", "?")
        except (OSError, ValueError) as e:
            ok = "online server %s not reachable (%s); LAN play is unaffected" % (online, e)
        if ok != said:
            log(ok)
            said = ok
        for _ in range(LAN_CHECKIN_SECONDS * 2):
            if rot.stopping:
                return
            time.sleep(0.5)


def main():
    ap = argparse.ArgumentParser(description="Run the LAN Party games in rotation and serve every client.")
    ap.add_argument("--port", type=int, default=8000, help="TCP port for browsers and handhelds (default 8000)")
    ap.add_argument("--minutes", type=float, default=30, help="minutes per game before switching (default 30)")
    ap.add_argument("--grace", type=float, default=5,
                    help="minutes to wait for a round to finish after the time is up (default 5)")
    ap.add_argument("--games", default="", help="comma-separated rotation order, e.g. racer,skate")
    ap.add_argument("--start", default="", help="game to start with (default: a random one)")
    ap.add_argument("--in-order", action="store_true",
                    help="play the games in the listed order instead of picking the next one at random")
    ap.add_argument("--config", default=os.path.join(HERE, "games.json"))
    ap.add_argument("--data", default=os.path.join(os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share")),
                                                   "lan-party-hub", "data"), help="where logs go")
    ap.add_argument("--fullscreen", action="store_true", help="show the game hosts fullscreen on this PC")
    ap.add_argument("--size", default="1280x720", help="window size for the game hosts")
    ap.add_argument("--verbose", action="store_true", help="log every HTTP request")
    ap.add_argument("--no-announcer", action="store_true", help="keep the announcer quiet")
    ap.add_argument("--announcer-volume", type=int, default=100, help="announcer volume, 0-100 (default 100)")
    ap.add_argument("--online", action="store_true",
                    help="run as the online server: no screen or speakers, host controls need --admin-key")
    ap.add_argument("--admin-key", default=os.environ.get("LAN_PARTY_ADMIN_KEY", ""),
                    help="password for the host controls from other devices (open /host?key=...)")
    ap.add_argument("--public-url", default="", help="the address players open, e.g. http://play.example.com:8000")
    ap.add_argument("--behind-proxy", action="store_true",
                    help="online server behind a reverse proxy: take device addresses from X-Forwarded-For")
    ap.add_argument("--online-server", default="",
                    help="LAN mode: the online server's address, so devices on this network that ask it are sent here")
    ap.add_argument("--updates", default=os.environ.get("LAN_PARTY_UPDATES", ""),
                    help="where this hub gets new games from (a release folder URL, see tools/publish.py); "
                         "default: the address in updates.url next to the hub, 'off' for none")
    args = ap.parse_args()
    if not args.updates:
        try:
            with open(os.path.join(HERE, "updates.url")) as f:
                args.updates = f.read().strip()
        except OSError:
            pass
    if args.updates == "off":
        args.updates = ""
    # After the hub updated itself it starts with the game it was about to switch to.
    resume = os.path.join(args.data, "resume")
    try:
        if time.time() - os.path.getmtime(resume) < 600 and not args.start:
            with open(resume) as f:
                args.start = f.read().strip()
        os.remove(resume)
    except OSError:
        pass
    if args.online and not args.admin_key:
        log("no --admin-key: the host controls only work from this machine")
    if not args.online and not args.admin_key:
        # A LAN party gets a 6-digit PIN, kept between runs, so the host controls also work from
        # a phone or laptop: open /host there and type it in.
        pin_file = os.path.join(args.data, "admin-pin")
        try:
            with open(pin_file) as f:
                args.admin_key = f.read().strip()
        except OSError:
            pass
        if not re.fullmatch(r"\d{4,12}", args.admin_key or ""):
            os.makedirs(args.data, exist_ok=True)
            args.admin_key = "%06d" % random.SystemRandom().randrange(1000000)
            with open(pin_file, "w") as f:
                f.write(args.admin_key + "\n")

    root = os.path.dirname(os.path.abspath(args.config))
    with open(args.config) as f:
        specs = json.load(f)["games"]
    games = [Game(s, root) for s in specs]
    try:
        # The set before the last update, so a game that keeps crashing can go back to it.
        with open(args.config + ".prev") as f:
            before = {s["id"]: Game(s, root) for s in json.load(f)["games"]}
        for g in games:
            was = before.get(g.id)
            if was and was.binary != g.binary and was.available():
                g.previous = was
    except (OSError, ValueError, KeyError):
        pass
    want = [x.strip() for x in args.games.split(",") if x.strip()]
    if want:
        games = [g for w in want for g in games if g.id == w]
    os.makedirs(args.data, exist_ok=True)

    rot = Rotation(games, args)
    rot.want = want
    rot.updater = Updater(args.updates, root, args.online, log)
    if args.updates:
        log("updates: from " + args.updates)

        def staged():
            with rot.lock:
                rot.bump()
        threading.Thread(target=rot.updater.loop, args=(staged, lambda: rot.stopping), daemon=True).start()

        def healthy():
            # A hub that has been up a few minutes after updating itself is a keeper.
            marker = os.path.join(root, "pkgs", "hub-updated")
            time.sleep(180)
            if not rot.stopping and rot.ready and os.path.exists(marker):
                os.remove(marker)
                log("updates: the new hub is running fine")
        threading.Thread(target=healthy, daemon=True).start()
    if not args.online:
        # The announcer is for the room around the host's screen; an online server has neither.
        rot.announcer = Announcer(os.path.join(HERE, "announcer"), args.data, volume=args.announcer_volume / 100,
                                  enabled=not args.no_announcer, log=log)
    Handler.rotation = rot
    Handler.lan_hubs = LanRegistry() if args.online else None
    Handler.bench = BenchStore(os.path.join(args.data, "bench"))
    ThreadingHTTPServer.daemon_threads = True
    ThreadingHTTPServer.allow_reuse_address = True
    try:
        httpd = ThreadingHTTPServer(("", args.port), Handler)
    except OSError as e:
        sys.exit("hub: cannot listen on tcp/%d: %s" % (args.port, e))
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    log("rotation: " + ", ".join(g.short for g in rot.order) + ", %g minutes each" % args.minutes)
    rot.addresses = local_addresses()
    if args.online:
        log("online server: players open %s" % (args.public_url or "http://<this server>:%d" % args.port))
        log("host controls: %s/host?key=<admin key>" % (args.public_url or "http://localhost:%d" % args.port))
    else:
        for a in rot.addresses:
            log("players open http://%s:%d   (handhelds: put %s in lanparty/server.txt)" % (a, args.port, a))
        log("host controls: http://localhost:%d/host, or /host on any device with PIN %s" % (args.port, args.admin_key))
        threading.Thread(target=answer_discovery, args=(rot,), daemon=True).start()
        if args.online_server:
            threading.Thread(target=check_in_online, args=(rot, args.online_server), daemon=True).start()

    def stop(*_):
        rot.stopping = True
    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    if not args.online:
        rot.redirects = PortRedirects([g.web_port for g in rot.games], args.port)
    rot.run()
    if args.online_server and not args.online and rot.exit_code != RESTART_CODE:
        check_in_online(rot, args.online_server, bye=True)
    httpd.shutdown()
    sys.exit(rot.exit_code)


if __name__ == "__main__":
    main()
