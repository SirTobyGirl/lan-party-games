// Shared by the hub pages: follows the host's rotation and drives the game pages in frames.
// The game pages are each game's own browser build, served by the hub from the same origin,
// so these helpers can restyle them and fill in their join form.
var Hub = (function () {
  var phone = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) ||
    (matchMedia('(pointer: coarse)').matches && !matchMedia('(pointer: fine)').matches);

  // Calls onState(state) now and again whenever anything changes on the host (long poll).
  // Unless opts.stay, it also moves the page between servers: from the online server to a LAN
  // party on this network when there is one, and from a LAN hub that has gone away to the online server.
  function watch(onState, opts) {
    var gen = -1, lostSince = 0, lastGood = null, asked = false;
    var key = adminKey();
    function next() {
      fetch('/api/state?since=' + gen + (key ? '&key=' + encodeURIComponent(key) : ''), { cache: 'no-store' })
        .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
        .then(function (s) {
          if (s.locked && location.pathname !== '/host') { location.replace('/unlock'); return; }
          gen = s.generation; lostSince = 0; lastGood = s;
          if (!asked && !(opts && opts.stay) && s.mode === 'online') { asked = true; lookForLan(); }
          onState(s); next();
        })
        .catch(function () {
          onState(null);
          if (!lostSince) lostSince = Date.now();
          // A LAN hub gone for 20 s (the party is over): carry on online, if it knows where that is.
          if (!(opts && opts.stay) && lastGood && lastGood.online_url && Date.now() - lostSince > 20000)
            moveTo(lastGood.online_url, 'The LAN party host has gone. Moving to the online server', false, 'left=lan');
          setTimeout(next, 2000);
        });
    }
    next();
  }

  // The online server knows which LAN hubs checked in from this device's internet connection.
  function lookForLan() {
    try {
      // Just came from a LAN hub that went away: the online server may still list it for a minute or two.
      var params = new URLSearchParams(location.search);
      if (params.get('left') === 'lan') {
        sessionStorage.setItem('lan-party-left-lan', String(Date.now()));
        params.delete('left');
        history.replaceState(null, '', location.pathname + (params.toString() ? '?' + params : ''));
      }
      if (sessionStorage.getItem('lan-party-stay-online')) return;
      if (Date.now() - Number(sessionStorage.getItem('lan-party-left-lan') || 0) < 120000) return;
    } catch (e) {}
    fetch('/api/lan', { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (j.hubs && j.hubs.length)
          moveTo(j.hubs[0].url, 'A LAN party is on at this place. Joining it', true);
      })
      .catch(function () {});
  }

  // Shows a notice, then opens the same page (and name) on the other server, unless the player says no.
  function moveTo(base, text, canStay, extra) {
    if (moveTo.busy) return;
    moveTo.busy = true;
    var search = location.search;
    if (extra) search += (search ? '&' : '?') + extra;
    var target = base.replace(/\/+$/, '') + location.pathname + search;
    var bar = document.createElement('div');
    bar.className = 'movebar';
    bar.setAttribute('role', 'status');
    var msg = document.createElement('span');
    bar.append(msg);
    if (canStay) {
      var stay = document.createElement('button');
      stay.type = 'button';
      stay.className = 'quiet';
      stay.textContent = 'Stay online';
      stay.onclick = function () {
        try { sessionStorage.setItem('lan-party-stay-online', '1'); } catch (e) {}
        clearInterval(t);
        bar.remove();
      };
      bar.append(stay);
    }
    document.body.append(bar);
    var n = 4;
    function tickDown() {
      msg.textContent = text + ' in ' + n + '…';
      if (n-- <= 0) { clearInterval(t); location.href = target; }
    }
    var t = setInterval(tickDown, 1000);
    tickDown();
  }

  // Host controls on the online server: /host?key=... once, remembered for this tab.
  function adminKey() {
    var k = new URLSearchParams(location.search).get('key');
    try {
      if (k) sessionStorage.setItem('lan-party-key', k);
      return k || sessionStorage.getItem('lan-party-key') || '';
    } catch (e) { return k || ''; }
  }

  // Game page in a frame: just the game screen, filling the frame.
  var KIOSK_CSS =
    'html,body{height:100%!important;margin:0!important;padding:0!important;overflow:hidden!important;background:#000!important}' +
    '.wrap{max-width:none!important;width:100%;height:100%;display:flex!important;align-items:center;justify-content:center;gap:0!important}' +
    '.wrap>header,.wrap>.bar,.controls,p.note,#status{display:none!important}' +
    '.screen{width:min(100vw,133.333vh)!important;border:0!important;border-radius:0!important}';

  function kiosk(frame) {
    try {
      var doc = frame.contentDocument;
      if (!doc || doc.getElementById('hub-kiosk')) return;
      var st = doc.createElement('style');
      st.id = 'hub-kiosk';
      st.textContent = KIOSK_CSS;
      (doc.head || doc.documentElement).appendChild(st);
    } catch (e) {}
  }

  // A spectator frame being watched wide: the picture fills the whole frame at the display's own
  // shape (16:9, 21:9 ultrawide...) instead of the 4:3 landing view. The spectator page's engine part
  // sizes its drawing to match, so it stays sharp. Remembered on the frame, so the next game is wide too.
  var WIDE_CSS = 'html body .screen{width:100vw!important;height:100vh!important;height:100dvh!important;max-width:none!important;aspect-ratio:auto!important}';

  function wide(frame, on) {
    if (on !== undefined) frame.dataset.wide = on ? '1' : '';
    try {
      var doc = frame.contentDocument;
      if (!doc) return;
      var st = doc.getElementById('hub-wide');
      if (frame.dataset.wide && !st) {
        st = doc.createElement('style');
        st.id = 'hub-wide';
        st.textContent = WIDE_CSS;
        (doc.head || doc.documentElement).appendChild(st);
      } else if (!frame.dataset.wide && st) {
        st.remove();
      }
    } catch (e) {}
  }

  // Browser sound. Pages open muted. Turning sound on plays at 50% of the games' own level, and the
  // slider runs 0-100% of that level. The games' Web Audio output is routed through one master gain
  // node per audio context, put in place as the game page loads (before its audio starts).
  var sound = { on: false, vol: 50, frames: [], listeners: [] };
  try {
    var sv = parseInt(localStorage.getItem('lan-party-volume'), 10);
    if (sv >= 0 && sv <= 100) sound.vol = sv;
  } catch (e) {}

  function soundLevel() { return sound.on ? sound.vol / 100 : 0; }

  function patchAudio(win) {
    try {
      if (!win || win.__hubAudio) return;
      var A = win.AudioContext || win.webkitAudioContext;
      if (!A) return;
      win.__hubAudio = true;
      win.__hubMasters = [];
      var Wrapped = function (opts) {
        var c = opts === undefined ? new A() : new A(opts);
        var g = c.createGain();
        g.gain.value = soundLevel();
        g.connect(c.destination);
        Object.defineProperty(c, 'destination', { get: function () { return g; } });
        win.__hubMasters.push({ ctx: c, gain: g });
        return c;
      };
      Wrapped.prototype = A.prototype;
      win.AudioContext = Wrapped;
      win.webkitAudioContext = Wrapped;
    } catch (e) {}
  }

  function applySound() {
    sound.frames.forEach(function (f) {
      try {
        var list = f.contentWindow.__hubMasters || [];
        list.forEach(function (m) {
          m.gain.gain.setTargetAtTime(soundLevel(), m.ctx.currentTime, 0.02);
          if (sound.on && m.ctx.state === 'suspended') m.ctx.resume();
        });
      } catch (e) {}
    });
    sound.listeners.forEach(function (fn) { fn(sound); });
  }
  function setSound(on) { sound.on = !!on; applySound(); }
  function setVolume(v) {
    sound.vol = Math.max(0, Math.min(100, Math.round(+v || 0)));
    try { localStorage.setItem('lan-party-volume', String(sound.vol)); } catch (e) {}
    applySound();
  }

  // Adds the sound button and volume slider to a page's corner bar.
  function soundControls(bar, frame) {
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'quiet';
    var vol = document.createElement('input');
    vol.type = 'range';
    vol.min = 0; vol.max = 100; vol.step = 5;
    vol.setAttribute('aria-label', 'Volume');
    vol.style.width = '90px';
    vol.hidden = true;
    function draw() {
      btn.textContent = sound.on ? 'Sound on' : 'Sound off';
      btn.setAttribute('aria-pressed', sound.on ? 'true' : 'false');
      vol.hidden = !sound.on;
      vol.value = sound.vol;
    }
    btn.addEventListener('click', function () { setSound(!sound.on); focusGame(frame); });
    vol.addEventListener('input', function () { setVolume(vol.value); });
    sound.listeners.push(draw);
    draw();
    bar.appendChild(btn);
    bar.appendChild(vol);
  }

  // The announcer on a spectator page: the hub streams each call as it is made (/api/voice), and the
  // page plays it at the page's own sound level, so a TV or laptop watching hears the commentary.
  // Games whose spectator has a commentary box (VOICE_GAMES) are told when the voice starts and
  // stops (spectator commands 7 and 8), so the commentators' mouths move with it.
  var VOICE_GAMES = ['skate'];
  function voice(frame) {
    var since = -1, ctx = null, gain = null, queue = [], busy = false;
    function level() { return soundLevel() * 1.6; }  // a voice sits above the games' effects
    function tell(c) {
      try {
        if (!VOICE_GAMES.some(function (g) { return (frame.dataset.url || '').indexOf('/g/' + g + '/') === 0; })) return;
        var M = frame.contentWindow.Module;
        if (M && M.ccall) M.ccall('lp_spectator_command', null, ['number'], [c]);
      } catch (e) {}
    }
    function audio() {
      if (ctx) return ctx;
      var A = window.AudioContext || window.webkitAudioContext;
      if (!A) return null;
      ctx = new A();
      gain = ctx.createGain();
      gain.gain.value = level();
      // A gentle low cut and presence lift: TV speakers make an 11 kHz voice sound muddy.
      var hp = ctx.createBiquadFilter();
      hp.type = 'highpass'; hp.frequency.value = 140;
      var pk = ctx.createBiquadFilter();
      pk.type = 'peaking'; pk.frequency.value = 2500; pk.Q.value = 0.9; pk.gain.value = 4;
      hp.connect(pk); pk.connect(gain); gain.connect(ctx.destination);
      ctx.__in = hp;
      return ctx;
    }
    sound.listeners.push(function () {
      if (!ctx) return;
      gain.gain.setTargetAtTime(level(), ctx.currentTime, 0.02);
      if (sound.on && ctx.state === 'suspended') ctx.resume();
    });
    function playNext() {
      if (busy || !queue.length) return;
      var url = queue.shift();
      if (!sound.on || !audio()) return playNext();
      busy = true;
      fetch(url, { cache: 'no-store' })
        .then(function (r) { if (!r.ok) throw new Error(r.status); return r.arrayBuffer(); })
        .then(function (buf) {
          return new Promise(function (ok, bad) { ctx.decodeAudioData(buf, ok, bad); });
        })
        .then(function (clip) {
          if (ctx.state === 'suspended') ctx.resume();
          var src = ctx.createBufferSource();
          src.buffer = clip;
          src.connect(ctx.__in);
          src.onended = function () { tell(8); busy = false; playNext(); };
          tell(7);
          src.start();
        })
        .catch(function () { busy = false; playNext(); });
    }
    function poll() {
      fetch('/api/voice?since=' + since, { cache: 'no-store' })
        .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
        .then(function (j) {
          if (j.off) return setTimeout(poll, 15000);  // announcer muted on the host page
          (j.calls || []).forEach(function (c) { if (queue.length < 3) queue.push(c.url); });
          since = j.n;
          playNext();
          poll();
        })
        .catch(function () { setTimeout(poll, 5000); });
    }
    poll();
  }

  // Loads url into the frame (if it isn't there already), restyled as a bare game screen.
  function show(frame, url) {
    if (frame.dataset.url === url) return false;
    frame.dataset.url = url;
    if (sound.frames.indexOf(frame) < 0) sound.frames.push(frame);
    frame.onload = function () { patchAudio(frame.contentWindow); kiosk(frame); wide(frame); };
    frame.src = url;
    // Style it as soon as the document exists, before the 1 MB page finishes loading.
    var tries = 0, t = setInterval(function () {
      try { patchAudio(frame.contentWindow); } catch (e) {}
      kiosk(frame);
      wide(frame);
      if (++tries > 100 || (frame.contentDocument && frame.contentDocument.getElementById('hub-kiosk'))) clearInterval(t);
    }, 50);
    return true;
  }

  // Waits for the game page's join form to be ready, then joins as `name` (and `age`, if given).
  function autojoin(frame, name, team, onJoined, age) {
    var url = frame.dataset.url, started = Date.now();
    var t = setInterval(function () {
      if (frame.dataset.url !== url || Date.now() - started > 90000) return clearInterval(t);
      try {
        var doc = frame.contentDocument;
        var btn = doc && doc.getElementById('join-btn');
        var form = doc && doc.getElementById('join');
        if (!btn || btn.disabled || !form || form.hidden) return;
        doc.getElementById('name').value = name;
        var ageBox = doc.getElementById('age');
        if (ageBox) ageBox.value = age || '';
        if (team) {
          var radio = doc.querySelector('#join input[name=team][value="' + team + '"]');
          if (radio) radio.checked = true;
        }
        clearInterval(t);
        btn.click();
        setTimeout(function () { focusGame(frame); }, 100);
        if (onJoined) onJoined();
      } catch (e) {}
    }, 250);
  }

  function focusGame(frame) {
    try {
      frame.contentWindow.focus();
      var c = frame.contentDocument.getElementById('canvas');
      if (c) c.focus();
    } catch (e) {}
  }

  function clock(sec) {
    var m = Math.floor(sec / 60), s = sec % 60;
    return m + ':' + (s < 10 ? '0' : '') + s;
  }

  // One line on what comes next, e.g. "Football in 12:34" or "Football after this race".
  function upNext(s) {
    if (!s || !s.next || s.games.length < 2) return '';
    if (s.hold) return 'Staying on ' + s.short;
    if (s.seconds_left === null || s.seconds_left === undefined) return '';
    if (s.waiting_for_round) return s.next.short + ' after this round';
    if (s.seconds_left === 0) return s.next.short + ' next';
    return s.next.short + ' in ' + clock(s.seconds_left);
  }

  function cleanName(v) {
    return (v || '').trim().replace(/[^A-Za-z0-9 ]/g, '').slice(0, 12);
  }
  function savedName() {
    try { return localStorage.getItem('lan-party-name') || ''; } catch (e) { return ''; }
  }
  function saveName(n) {
    try { localStorage.setItem('lan-party-name', n); } catch (e) {}
  }
  // Age for the games' assists: a whole number 1-120, or '' (the games then use 12).
  function cleanAge(v) {
    var n = parseInt(v, 10);
    return n >= 1 && n <= 120 ? String(n) : '';
  }
  function savedAge() {
    try { return cleanAge(localStorage.getItem('lan-party-age')); } catch (e) { return ''; }
  }
  function saveAge(a) {
    try {
      if (a) localStorage.setItem('lan-party-age', a);
      else localStorage.removeItem('lan-party-age');
    } catch (e) {}
  }

  return { phone: phone, watch: watch, adminKey: adminKey, show: show, kiosk: kiosk, wide: wide, autojoin: autojoin, focusGame: focusGame, soundControls: soundControls, setSound: setSound, voice: voice,
           clock: clock, upNext: upNext, cleanName: cleanName, savedName: savedName, saveName: saveName,
           cleanAge: cleanAge, savedAge: savedAge, saveAge: saveAge };
})();
