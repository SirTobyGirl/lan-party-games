"""Keeps a hub's games up to date from a published release (tools/publish.py makes one).

The release holds manifest.json plus one package per game, one for the hub itself and one for
the announcer's voice clips, each named <kind>.<id>.<first 12 of sha256>.tar.gz. The hub checks
the manifest every few minutes, downloads only the packages it doesn't have, checks every
file's SHA-256, and unpacks each into pkgs/<id>-<sha>/ next to the hub. Nothing changes while a
game is being played: the rotation calls apply() between games, which rewrites games.json to
point at the new packages. A new hub or announcer package also restarts the hub (exit code 75,
which the launcher answers by starting it again).

Rollback: games.json.prev is the previous set, a game that keeps crashing goes back to its
previous package (Rotation.revert_game), and a hub that fails to start after updating itself
is put back by the launcher from pkgs/hub-prev/.

Python 3 standard library only.
"""
import hashlib
import io
import json
import os
import shutil
import tarfile
import threading
import time
import urllib.request

RESTART_CODE = 75            # the launcher starts the hub again when it exits with this
CHECK_MINUTES = 10           # how often the hub looks for a new manifest
USER_AGENT = "lan-party-hub-updater"


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def safe_extract(data, dest):
    """Unpacks a .tar.gz into dest, refusing anything that would land outside it or isn't a
    plain file or folder."""
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tar:
        for m in tar.getmembers():
            target = os.path.realpath(os.path.join(dest, m.name))
            if not (target == os.path.realpath(dest) or target.startswith(os.path.realpath(dest) + os.sep)):
                raise ValueError("package path escapes: " + m.name)
            if not (m.isfile() or m.isdir()):
                raise ValueError("package has a link or device: " + m.name)
        if hasattr(tarfile, "data_filter"):
            tar.extractall(dest, filter="data")
        else:
            tar.extractall(dest)


def write_atomic(path, data):
    tmp = path + ".new"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, path)


class Updater:
    def __init__(self, url, root, online, log, minutes=CHECK_MINUTES):
        self.url = url.rstrip("/") + "/" if url else ""
        self.root = root                       # the hub's own folder (games.json lives here)
        self.pkgs = os.path.join(root, "pkgs")
        self.online = online                   # the online server skips the announcer's clips
        self.log = log
        self.minutes = minutes
        self.lock = threading.Lock()
        self.busy = threading.Lock()           # held while check() downloads
        self.staged = None                     # a downloaded update waiting for the next switch
        self.force = False                     # Update now on the host page
        self.wake = threading.Event()
        self.message = "updates are off" if not url else "not checked yet"
        self.checked = 0.0
        self.applied_at = 0.0

    # ---- what is installed --------------------------------------------------
    def config_path(self):
        return os.path.join(self.root, "games.json")

    def installed(self):
        try:
            with open(self.config_path()) as f:
                return json.load(f)
        except (OSError, ValueError):
            return {"games": []}

    def installed_version(self):
        return str(self.installed().get("version", ""))

    def skipped(self):
        """A version that failed here (the launcher wrote it after putting the old hub back)."""
        try:
            with open(os.path.join(self.pkgs, "skip")) as f:
                return f.read().strip()
        except OSError:
            return ""

    def skip(self, version):
        os.makedirs(self.pkgs, exist_ok=True)
        with open(os.path.join(self.pkgs, "skip"), "w") as f:
            f.write(version + "\n")

    # ---- talking to the release ---------------------------------------------
    def fetch(self, name, limit=256 << 20):
        req = urllib.request.Request(self.url + name, headers={"User-Agent": USER_AGENT, "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=60) as r:
            data = r.read(limit + 1)
        if len(data) > limit:
            raise ValueError(name + " is too big")
        return data

    def fetch_package(self, pkg, dest):
        """Downloads one package into dest (a folder under pkgs/), unless it is already there."""
        if os.path.isfile(os.path.join(dest, ".sha256")):
            with open(os.path.join(dest, ".sha256")) as f:
                if f.read().strip() == pkg["sha256"]:
                    return False
        data = self.fetch(pkg["file"])
        if sha256_bytes(data) != pkg["sha256"]:
            raise ValueError(pkg["file"] + " does not match its checksum")
        tmp = dest + ".part"
        shutil.rmtree(tmp, ignore_errors=True)
        os.makedirs(tmp)
        safe_extract(data, tmp)
        with open(os.path.join(tmp, ".sha256"), "w") as f:
            f.write(pkg["sha256"] + "\n")
        shutil.rmtree(dest, ignore_errors=True)
        os.replace(tmp, dest)
        return True

    def check(self):
        """Looks for a newer manifest and downloads what it needs. Safe to call any time: it
        never touches what the hub is running."""
        if not self.url:
            return
        with self.busy:
            self._check()

    def _check(self):
        self.checked = time.time()
        try:
            manifest = json.loads(self.fetch("manifest.json", 1 << 20))
            version = str(manifest["version"])
            have = self.installed_version()
            if version <= have:
                self.force = False
                self.set_message("up to date")
                return
            if version == self.skipped():
                self.set_message("version %s failed here before, staying on %s" % (version, have or "the installed one"))
                return
            if self.staged and self.staged["version"] == version:
                return
            os.makedirs(self.pkgs, exist_ok=True)
            specs, got = [], 0
            for spec in manifest["games"]:
                pkg = spec["package"]
                folder = "%s-%s" % (spec["id"], pkg["sha256"][:12])
                got += self.fetch_package(pkg, os.path.join(self.pkgs, folder))
                local = {k: v for k, v in spec.items() if k != "package"}
                for key in ("binary", "web", "handheld"):
                    local[key] = "pkgs/%s/%s" % (folder, spec[key])
                local["sha256"] = pkg["sha256"]
                exe = os.path.join(self.root, local["binary"])
                if os.path.isfile(exe):
                    os.chmod(exe, 0o755)
                hh = os.path.join(self.root, local["handheld"])
                for name in os.listdir(hh) if os.path.isdir(hh) else []:
                    os.chmod(os.path.join(hh, name), 0o755)
                specs.append(local)
            hub_dir = ann_dir = None
            if manifest.get("hub") and manifest["hub"]["sha256"] != self.installed().get("hub_sha256"):
                hub_dir = os.path.join(self.pkgs, "hub-" + manifest["hub"]["sha256"][:12])
                got += self.fetch_package(manifest["hub"], hub_dir)
            if manifest.get("announcer") and not self.online and \
                    manifest["announcer"]["sha256"] != self.installed().get("announcer_sha256"):
                ann_dir = os.path.join(self.pkgs, "announcer-" + manifest["announcer"]["sha256"][:12])
                got += self.fetch_package(manifest["announcer"], ann_dir)
            with self.lock:
                self.staged = {"version": version, "games": specs, "hub_dir": hub_dir, "announcer_dir": ann_dir,
                               "hub_sha256": (manifest.get("hub") or {}).get("sha256"),
                               "announcer_sha256": (manifest.get("announcer") or {}).get("sha256")}
            self.set_message("version %s downloaded (%d new package%s), installs between games"
                             % (version, got, "" if got == 1 else "s"))
        except Exception as e:  # noqa: BLE001 - any failure just means "try again later"
            self.set_message("could not check for updates (%s); will try again" % e)

    def set_message(self, msg):
        if msg != self.message:
            self.log("updates: " + msg)
        self.message = msg

    def loop(self, on_checked, stopping):
        """The background thread: check now, then every few minutes or when asked."""
        while not stopping():
            self.check()
            on_checked()
            self.wake.wait(self.minutes * 60)
            self.wake.clear()

    def check_now(self):
        self.force = True
        self.wake.set()

    # ---- installing, between games ------------------------------------------
    def apply(self):
        """Installs the staged update. Called by the rotation with no game running.
        Returns (game specs, restart needed)."""
        with self.lock:
            st, self.staged, self.force = self.staged, None, False
        if not st:
            return None, False
        old = self.installed()
        new = {"version": st["version"], "games": st["games"],
               "hub_sha256": st["hub_sha256"] or old.get("hub_sha256"),
               "announcer_sha256": old.get("announcer_sha256")}
        restart = False
        if st["announcer_dir"]:
            live = os.path.join(self.root, "announcer")
            prev = os.path.join(self.pkgs, "announcer-prev")
            shutil.rmtree(prev, ignore_errors=True)
            if os.path.isdir(live):
                os.replace(live, prev)
            shutil.copytree(os.path.join(st["announcer_dir"], "voice"), live)
            new["announcer_sha256"] = st["announcer_sha256"]
            restart = True
        if st["hub_dir"]:
            self.install_hub(st["hub_dir"])
            restart = True
        write_atomic(self.config_path() + ".prev", json.dumps(old, indent=1).encode())
        write_atomic(self.config_path(), json.dumps(new, indent=1).encode())
        if restart:
            # The launcher puts pkgs/hub-prev back if the new hub won't start.
            with open(os.path.join(self.pkgs, "hub-updated"), "w") as f:
                f.write(st["version"] + "\n")
        self.applied_at = time.time()
        # Not while a check is downloading: it may be filling a folder this would remove.
        if self.busy.acquire(blocking=False):
            try:
                self.cleanup(old, new)
            finally:
                self.busy.release()
        self.set_message("installed version %s" % st["version"])
        return new["games"], restart

    def install_hub(self, src):
        """Copies the new hub's files over this one, keeping the old ones in pkgs/hub-prev/.
        Every file is replaced by a rename, so a script that is running keeps its old copy."""
        prev = os.path.join(self.pkgs, "hub-prev")
        shutil.rmtree(prev, ignore_errors=True)
        for dirpath, _, files in os.walk(src):
            rel = os.path.relpath(dirpath, src)
            for name in files:
                if rel == "." and name == ".sha256":
                    continue
                rel_file = os.path.normpath(os.path.join(rel, name))
                live = os.path.join(self.root, rel_file)
                if os.path.isfile(live):
                    os.makedirs(os.path.dirname(os.path.join(prev, rel_file)), exist_ok=True)
                    shutil.copy2(live, os.path.join(prev, rel_file))
                os.makedirs(os.path.dirname(live), exist_ok=True)
                shutil.copy2(os.path.join(dirpath, name), live + ".new")
                os.replace(live + ".new", live)

    def revert_game(self, game_id, spec):
        """A game that keeps crashing after an update goes back to the package it had before."""
        cfg = self.installed()
        cfg["games"] = [spec if g["id"] == game_id else g for g in cfg["games"]]
        write_atomic(self.config_path(), json.dumps(cfg, indent=1).encode())
        self.skip(str(cfg.get("version", "")))
        self.set_message("%s kept crashing after the update, so it went back to its previous build" % game_id)

    def cleanup(self, old, new):
        """Keeps the packages the current and previous games.json use, removes the rest."""
        keep = set()
        for cfg in (old, new):
            for g in cfg.get("games", []):
                parts = g.get("binary", "").split("/")
                if len(parts) > 2 and parts[0] == "pkgs":
                    keep.add(parts[1])
        try:
            names = os.listdir(self.pkgs)
        except OSError:
            return
        for name in names:
            path = os.path.join(self.pkgs, name)
            if not os.path.isdir(path) or name in keep or name in ("hub-prev", "announcer-prev"):
                continue
            # Hub and announcer packages are copied in, so only the newest is worth keeping.
            shutil.rmtree(path, ignore_errors=True)

    def state(self):
        with self.lock:
            staged = self.staged["version"] if self.staged else None
        return {"on": bool(self.url), "version": self.installed_version(), "ready": staged,
                "message": self.message, "checked": int(time.time() - self.checked) if self.checked else None}
