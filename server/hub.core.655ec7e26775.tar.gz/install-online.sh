#!/bin/bash
# Installs LAN Party Host as the ONLINE server: the same hub and games, run as a system service
# on an internet-facing Linux box (a VPS, or an always-on PC with ports forwarded). No screen,
# speakers or desktop needed. Run as root from the unpacked lan-party-hub folder:
#   sudo ./install-online.sh [--public-url http://play.example.com:8000]
# Settings: /etc/lan-party/online.conf. Logs: journalctl -u lan-party-online.
set -e
[ "$(id -u)" = 0 ] || { echo "Run with sudo: sudo $0 $*"; exit 1; }
src=$(cd "$(dirname "$0")" && pwd)
dest=/opt/lan-party-hub
conf=/etc/lan-party/online.conf
public_url=""
[ "$1" = --public-url ] && public_url=$2

command -v python3 >/dev/null || { echo "python3 is needed"; exit 1; }
# The game hosts draw nothing online, but still open an offscreen GL context, which needs Mesa's EGL.
if ! ldconfig -p | grep -q 'libEGL.so.1' || ! ldconfig -p | grep -q 'libGLESv2.so.2'; then
    echo "Installing Mesa's EGL and GLES libraries"
    if command -v apt-get >/dev/null; then
        apt-get install -y libegl1 libgles2 libgl1-mesa-dri
    elif command -v dnf >/dev/null; then
        dnf install -y mesa-libEGL mesa-libGLES mesa-dri-drivers
    elif command -v rpm-ostree >/dev/null; then
        echo "Bazzite and other image-based systems already ship Mesa; continuing"
    else
        echo "Install Mesa's libEGL and libGLESv2 with your package manager, then run this again"; exit 1
    fi
fi

id lanparty >/dev/null 2>&1 || useradd --system --home-dir /var/lib/lan-party --create-home --shell /usr/sbin/nologin lanparty
mkdir -p "$dest" /etc/lan-party
rm -rf "$dest/games" "$dest/web" "$dest/handheld"
# No announcer clips: nobody hears the online server.
cp -r "$src/games" "$src/web" "$src/handheld" "$dest/"
cp "$src/lan-party-hub.py" "$src/announcer.py" "$src/updater.py" "$src/games.json" "$dest/"
rm -f "$dest/updates.url"
[ -f "$src/updates.url" ] && cp "$src/updates.url" "$dest/"
chmod +x "$dest"/games/*/* "$dest/lan-party-hub.py"
# The server installs new games and hub versions itself (updater.py), so it owns its folder.
mkdir -p "$dest/pkgs"
chown -R lanparty:lanparty "$dest"

if [ ! -f "$conf" ]; then
    key=$(head -c 18 /dev/urandom | base64 | tr -d '/+=' | cut -c1-20)
    cat > "$conf" <<CONF
# LAN Party online server settings. Restart after a change: systemctl restart lan-party-online
# PUBLIC_URL: the address players open (shown on the pages). Put the same address on an
# "online" line in the GitHub address file and in each LAN hub's ONLINE_SERVER.
PUBLIC_URL="$public_url"
# ADMIN_KEY: the host controls are at PUBLIC_URL/host?key=ADMIN_KEY
ADMIN_KEY="$key"
MINUTES=30
GAMES=""
PORT=8000
# BEHIND_PROXY=1 when a reverse proxy (Caddy, nginx) in front adds https.
BEHIND_PROXY=0
# UPDATES: where new games come from (hub/tools/publish.py). Empty: the address the package
# came with (updates.url). "off": never update by itself.
UPDATES=""
CONF
    chmod 640 "$conf"
    chgrp lanparty "$conf"
fi

cat > "$dest/lan-party-online" <<'RUN'
#!/bin/bash
# Started by lan-party-online.service with the settings in /etc/lan-party/online.conf.
. /etc/lan-party/online.conf
args=(--online --port "${PORT:-8000}" --minutes "${MINUTES:-30}" --data /var/lib/lan-party/data)
[ -n "$PUBLIC_URL" ] && args+=(--public-url "$PUBLIC_URL")
[ -n "$GAMES" ] && args+=(--games "$GAMES")
[ "$BEHIND_PROXY" = 1 ] && args+=(--behind-proxy)
[ -n "$UPDATES" ] && args+=(--updates "$UPDATES")
export LAN_PARTY_ADMIN_KEY="$ADMIN_KEY"
here=/opt/lan-party-hub
# Exit code 75: the hub installed a new version of itself, start it again. A new hub that
# fails is swapped back for pkgs/hub-prev/ and that version is skipped.
while :; do
    python3 "$here/lan-party-hub.py" "${args[@]}"
    code=$?
    [ $code = 75 ] && continue
    if [ $code != 0 ] && [ -f "$here/pkgs/hub-updated" ] && [ -d "$here/pkgs/hub-prev" ]; then
        echo "the updated hub stopped with code $code, putting the previous one back"
        (cd "$here/pkgs/hub-prev" && find . -type f) | while read -r f; do
            cp "$here/pkgs/hub-prev/$f" "$here/$f.rb" && mv -f "$here/$f.rb" "$here/$f"
        done
        cp "$here/pkgs/hub-updated" "$here/pkgs/skip"
        rm -f "$here/pkgs/hub-updated"
        [ -f "$here/games.json.prev" ] && cp "$here/games.json.prev" "$here/games.json"
        continue
    fi
    exit $code
done
RUN
chmod +x "$dest/lan-party-online"

cat > /etc/systemd/system/lan-party-online.service <<UNIT
[Unit]
Description=LAN Party online server
After=network-online.target
Wants=network-online.target

[Service]
User=lanparty
ExecStart=$dest/lan-party-online
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now lan-party-online
systemctl restart lan-party-online

# TCP 8000 for browsers, handhelds and PCs; UDP 47800-47899 for the games, so a new game that
# arrives by update (each takes a port in that range) needs no firewall change.
ports="8000/tcp 47800:47899/udp"
if command -v ufw >/dev/null && ufw status | grep -q active; then
    for p in $ports; do ufw allow "$p"; done
elif command -v firewall-cmd >/dev/null && firewall-cmd --state >/dev/null 2>&1; then
    for p in $ports; do firewall-cmd --permanent --add-port="${p/:/-}"; done
    firewall-cmd --reload
else
    echo "No firewall tool found: make sure $ports are open (and in your cloud provider's firewall)."
fi

. "$conf"
echo
echo "LAN Party online server is running."
echo "  Players:       ${PUBLIC_URL:-http://<this server>:8000}"
echo "  Host controls: ${PUBLIC_URL:-http://<this server>:8000}/host?key=$ADMIN_KEY"
echo "  Settings:      $conf      Logs: journalctl -u lan-party-online -f"
echo "Next: add \"online ${PUBLIC_URL:-<this server>:8000}\" to the GitHub address file, and"
echo "ONLINE_SERVER=\"${PUBLIC_URL:-http://<this server>:8000}\" to each LAN hub's ~/.config/lan-party/hub.conf."
