"""Announcer: a hyped 90s sound-card voice that calls out what happens in the running game.

It only ever plays on the host PC, through its own speakers, so none of the clips are in the
browser, handheld or game builds. Like the rest of the hub it needs no changes to the games: it
listens to the same log lines the hub already reads, and follows the logs the game hosts write
(racer: car positions, football: goals, skate and archery: results).

Clips live in announcer/ next to this file:
  shared/<line>.wav   lines every game uses ("wins!", "get ready!", ...)
  <game>/<line>.wav   lines for one game ("final lap!", "goal!", "bullseye!", ...)
  names/<key>.wav     a player's name, key = lower-case letters and digits ("Nee Nah" -> neenah)
They are 11 kHz 8-bit mono WAVs made by announcer/tools/build-voice.py (see the README there).
A line with a name is the name clip followed by a shared or game line ("Mina" + "wins!").
Names without a clip get the nameless version ("We have a winner!").

Games can also ask for a line directly by printing `announce: <game or shared>/<line> [name]`,
e.g. `announce: skate/sick_combo Mina`, which plays "Mina! Sick combo!".

Python 3 standard library only. Plays with pw-play, paplay or aplay, whichever the host has.
"""
import csv
import io
import os
import queue
import random
import re
import shutil
import subprocess
import threading
import time
import wave

GAP = b"\x80" * 330  # 30 ms of 8-bit silence between a name and its line

RACE_START_RE = re.compile(r"host: race (\d+) starting")
FINISHED_RE = re.compile(r"host: (.*) finished in ")
LOGGING_RE = re.compile(r"host: logging to (.+)$")
RESULTS_RE = re.compile(r"host: results in (.+)$")
KICKOFF_RE = re.compile(r"host: kick-off")
FULLTIME_RE = re.compile(r"host: full time, red (\d+) blue (\d+)")
ANNOUNCE_RE = re.compile(r"announce: ([a-z0-9_-]+/[a-z0-9_-]+)(?: (.+))?$")
RACER_LAPS = 3        # the racer host's default race length
RACERS = ("racer", "racer2")  # racer v2 writes the same log lines and race logs
LEAD_CALL_GAP = 8.0   # seconds between "takes the lead!" calls


def key(name):
    return re.sub(r"[^a-z0-9]", "", name.lower())


def find_player():
    for cmd in ("pw-play", "paplay", "aplay"):
        path = shutil.which(cmd)
        if path:
            return [path] + (["-q"] if cmd == "aplay" else [])
    return None


class Announcer:
    def __init__(self, voice_dir, data_dir, volume=1.0, enabled=True, log=print):
        self.dir = voice_dir
        self.data = data_dir
        self.volume = max(0.0, min(1.0, volume))
        self.log = log
        self.player = find_player()
        self.available = self.player is not None and os.path.isdir(voice_dir)
        self.enabled = enabled and self.available
        if not self.player:
            log("announcer: no pw-play, paplay or aplay found, staying quiet")
        elif not os.path.isdir(voice_dir):
            log("announcer: no clips in " + voice_dir + ", staying quiet")
        self.q = queue.Queue(maxsize=6)
        self.game = None
        self.run = 0          # bumps per game start, so followers of an old game stop
        self.started = 0.0
        self.lock = threading.Lock()
        self.reset_round()
        threading.Thread(target=self.speaker, daemon=True).start()

    # ---- clips ---------------------------------------------------------------
    def clip(self, name):
        path = os.path.join(self.dir, name + ".wav")
        return path if os.path.isfile(path) else None

    def line(self, line_id):
        """'wins' -> the game's own clip if it has one, else the shared one."""
        if "/" in line_id:
            return self.clip(line_id)
        return (self.game and self.clip(self.game + "/" + line_id)) or self.clip("shared/" + line_id)

    def name(self, who):
        return self.clip("names/" + key(who)) if who and key(who) else None

    def say(self, *line_ids, who=None, fallback=None, keep=4.0, delay=0.0):
        """Queue a line. With who: the name clip then the lines, or `fallback` when there is no name clip.
        keep: drop it if it can't start within this many seconds (old news)."""
        if not self.enabled:
            return
        parts = []
        if who is not None:
            n = self.name(who)
            if n:
                parts.append(n)
            elif fallback:
                line_ids = fallback if isinstance(fallback, tuple) else (fallback,)
            else:
                return
        parts += [p for p in (self.line(i) for i in line_ids) if p]
        if not parts:
            return
        due = time.time() + delay
        try:
            self.q.put_nowait((due, due + keep, parts))
        except queue.Full:
            pass

    def speaker(self):
        n = 0
        while True:
            due, expires, parts = self.q.get()
            wait = due - time.time()
            if wait > 0:
                time.sleep(wait)
            if time.time() > expires or not self.enabled:
                continue
            n += 1
            path = os.path.join(self.data, "announcer-%d.wav" % (n % 2))
            try:
                self.compose(parts, path)
                subprocess.run(self.player + [path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               timeout=15)
            except (OSError, wave.Error, subprocess.SubprocessError) as e:
                self.log("announcer: cannot play: %s" % e)

    def compose(self, parts, path):
        frames = []
        for i, p in enumerate(parts):
            with wave.open(p, "rb") as w:
                if i == 0:
                    params = w.getparams()
                else:
                    frames.append(GAP)
                frames.append(w.readframes(w.getnframes()))
        data = b"".join(frames)
        if self.volume < 1.0:
            v = self.volume
            data = bytes(int(128 + (b - 128) * v) for b in data)
        with wave.open(path, "wb") as out:
            out.setparams(params)
            out.writeframes(data)

    # ---- the rotation --------------------------------------------------------
    def set_enabled(self, on):
        self.enabled = on and self.available

    def game_starting(self, game_id, first, restart=False):
        with self.lock:
            self.game = game_id
            self.run += 1
            self.started = time.time()
            self.reset_round()
        if restart:
            return
        if first:
            self.say("welcome", "title", keep=20, delay=1.0)
        else:
            self.say("next_up", "title", keep=20, delay=1.0)

    def reset_round(self):
        self.winner_called = False
        self.leader = None
        self.lead_called = 0.0
        self.final_lap_called = False
        self.racing = False

    # ---- log lines from the running game host --------------------------------
    def host_line(self, text, joined=None):
        """Called for every log line of the running game. joined: a player's name if the hub saw a join."""
        if not self.enabled:
            return
        g = self.game
        if joined:
            # Everyone rejoins right after a switch; only call people who drop in later.
            if time.time() - self.started > 15:
                self.say("joins", who=joined, fallback="new_challenger", keep=3)
        elif m := ANNOUNCE_RE.search(text):
            who = m.group(2)
            if who:
                self.say(m.group(1), who=who, fallback=m.group(1))
            else:
                self.say(m.group(1))
        elif g in RACERS and RACE_START_RE.search(text):
            with self.lock:
                self.reset_round()
            self.say("start_engines", keep=1.5)
            self.say("go", delay=2.9, keep=0.5)    # the racer counts down 3 s from this line
        elif g in RACERS and (m := FINISHED_RE.search(text)):
            if not self.winner_called:
                self.winner_called = True
                self.say("wins", who=m.group(1), fallback=("checkered_flag", "winner"), keep=8)
        elif g == "football" and KICKOFF_RE.search(text):
            self.say("kick_off", keep=3)
        elif g == "football" and (m := FULLTIME_RE.search(text)):
            red, blue = int(m.group(1)), int(m.group(2))
            self.say("full_time", "red_wins" if red > blue else "blue_wins" if blue > red else "draw", keep=10)
        elif (m := LOGGING_RE.search(text)) and g in RACERS + ("football",):
            path = m.group(1).strip()
            if not os.path.isabs(path):
                path = os.path.join(self.data, path)
            threading.Thread(target=self.follow, args=(path, g, self.run), daemon=True).start()
        elif m := RESULTS_RE.search(text):
            self.results(m.group(1).strip())

    def results(self, path):
        """Skate and archery: rank,name,score,... written when a round ends."""
        if not os.path.isabs(path):
            path = os.path.join(self.data, path)
        try:
            with open(path, newline="") as f:
                rows = [r for r in csv.reader(f) if r and r[0].strip() == "1"]
        except OSError:
            return
        if rows:
            line = {"skate": "takes_crown", "archery": "champion"}.get(self.game, "wins")
            self.say(line, who=rows[0][1], fallback=("game_over", "winner"), keep=10)

    # ---- following a game's live log file -------------------------------------
    def follow(self, path, game, run):
        for _ in range(50):
            if os.path.exists(path):
                break
            time.sleep(0.1)
        try:
            f = open(path, newline="")
        except OSError:
            return
        with f:
            header = None
            buf = ""
            while self.run == run:
                chunk = f.read()
                if not chunk:
                    time.sleep(0.2)
                    if not os.path.exists(path):
                        return
                    continue
                buf += chunk
                *lines, buf = buf.split("\n")
                for row in csv.reader(io.StringIO("\n".join(lines))):
                    if not row:
                        continue
                    if game in RACERS:
                        if header is None:
                            header = row
                            continue
                        self.racer_row(dict(zip(header, row)))
                    elif game == "football":
                        self.football_row(row)

    def racer_row(self, r):
        # One row per car per tick: lap, position, state (2 = racing), name.
        try:
            if r.get("state") != "2" or r.get("position") != "1":
                return
            lap, ms, name = int(r["lap"]), int(r["race_ms"]), r.get("name", "")
        except (KeyError, ValueError):
            return
        now = time.time()
        if lap == RACER_LAPS and not self.final_lap_called and r.get("finished") == "0":
            self.final_lap_called = True
            self.say("final_lap", keep=3)
        if name and name != self.leader:
            if self.leader is not None and ms > 8000 and now - self.lead_called > LEAD_CALL_GAP:
                self.lead_called = now
                self.say("takes_lead", who=name, keep=2)
            self.leader = name

    def football_row(self, row):
        # minute,goal|own_goal,red|blue,scorer,red score,blue score
        if len(row) < 4 or row[1] not in ("goal", "own_goal"):
            return
        team, scorer = row[2], row[3]
        if row[1] == "own_goal":
            self.say("own_goal", "goal_" + team, keep=5)
        elif self.name(scorer):
            self.say("goal", keep=5)
            self.say("scores", who=scorer, keep=6)
        else:
            self.say("goal_" + team, keep=5)
        if random.random() < 0.3:
            self.say("what_a_strike", keep=6)
