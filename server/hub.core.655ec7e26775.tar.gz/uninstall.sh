#!/bin/bash
# Removes LAN Party Host from this user account. Logs and settings are kept unless you
# pass --all. Firewall rules, if added, are left as they are:
#   sudo firewall-cmd --permanent --remove-port=8000/tcp --remove-port=8001/tcp --remove-port=47800/udp \
#        --remove-port=47810/udp --remove-port=47820/udp --remove-port=47830/udp --remove-port=47840/udp --remove-port=47850/udp --remove-port=47860/udp && sudo firewall-cmd --reload
dest="${XDG_DATA_HOME:-$HOME/.local/share}/lan-party-hub"
apps="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
rm -f "$apps/lan-party-hub.desktop" "$apps/lan-party-late-night.desktop" "$HOME/.local/bin/lan-party-hub" \
    "$HOME/.local/bin/lan-party-late-night" "$HOME/.local/bin/lan-party-hub-check"
rm -rf "$dest/games" "$dest/web" "$dest/handheld" "$dest/pkgs" "$dest/announcer"
rm -f "$dest"/{lan-party-hub.py,announcer.py,updater.py,updates.url,games.json,games.json.prev,lan-party-hub,lan-party-late-night,lan-party-hub-check,lan-party-hub.png,uninstall.sh,install-online.sh}
if [ "$1" = "--all" ]; then
    rm -rf "$dest" "${XDG_CONFIG_HOME:-$HOME/.config}/lan-party/hub.conf"
fi
update-desktop-database "$apps" >/dev/null 2>&1 || true
echo "LAN Party Host removed."
