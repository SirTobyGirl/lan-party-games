#!/bin/bash
# Installs LAN Party Host for the current user on Bazzite (or any desktop Linux with python3).
# Nothing goes outside your home folder except the optional firewall rule.
#   ./install.sh               install, and offer to open the ports
#   ./install.sh --no-firewall install only
set -e
src=$(cd "$(dirname "$0")" && pwd)
dest="${XDG_DATA_HOME:-$HOME/.local/share}/lan-party-hub"
apps="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
conf_dir="${XDG_CONFIG_HOME:-$HOME/.config}/lan-party"
web_port=8000              # TCP: browsers and handheld downloads
# Ranges rather than one port per game, so a game that arrives by update needs no firewall change.
game_web_ports="8080-8199"  # TCP: the addresses on each game's lobby screen; they send browsers to the hub
udp_ports="47799-47899"     # UDP: LAN discovery, then one port per game for its players

mkdir -p "$dest" "$apps" "$conf_dir" "$HOME/.local/bin"
rm -rf "$dest/games" "$dest/web" "$dest/handheld" "$dest/announcer"
cp -r "$src/games" "$src/web" "$src/handheld" "$src/announcer" "$dest/"
rm -f "$dest/updates.url"
[ -f "$src/updates.url" ] && cp "$src/updates.url" "$dest/"
for f in lan-party-hub.py announcer.py updater.py games.json lan-party-hub lan-party-hub-check lan-party-hub.png uninstall.sh install-online.sh; do
    cp "$src/$f" "$dest/$f"
done
chmod +x "$dest"/games/*/* "$dest/lan-party-hub.py" "$dest/lan-party-hub" "$dest/lan-party-hub-check" "$dest/uninstall.sh"
ln -sf "$dest/lan-party-hub" "$HOME/.local/bin/lan-party-hub"
# Earlier versions had a late-night hub; take its menu entry and command away on upgrade.
rm -f "$dest/lan-party-late-night" "$HOME/.local/bin/lan-party-late-night" "$apps/lan-party-late-night.desktop"
ln -sf "$dest/lan-party-hub-check" "$HOME/.local/bin/lan-party-hub-check"

if [ ! -f "$conf_dir/hub.conf" ]; then
    cat > "$conf_dir/hub.conf" <<CONF
# LAN Party Host settings.
# MINUTES: how long each game runs before the next (it waits for the round to end).
# GAMES: which games to play, e.g. "racer,skate". Empty means every game.
# The next game is picked at random (never the same one twice in a row); IN_ORDER=1 plays GAMES in order.
MINUTES=30
GAMES=""
IN_ORDER=0
# ANNOUNCER: 1 for the hyped voice on this PC's speakers, 0 for quiet. ANNOUNCER_VOLUME: 0-100.
ANNOUNCER=1
ANNOUNCER_VOLUME=100
# ONLINE_SERVER: the online server's address, e.g. "http://play.example.com:8000". This hub then
# checks in with it, so phones that open the online address here are sent to this LAN party,
# and browsers here move online when this hub is closed. Empty: LAN only.
ONLINE_SERVER=""
# UPDATES: where new games come from. Empty: the address this package came with. "off": never
# update by itself. Updates install between games, never in the middle of one.
UPDATES=""
CONF
fi

cat > "$apps/lan-party-hub.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=LAN Party Host
Comment=Run the LAN Party games in rotation for everyone on the network
Exec=$dest/lan-party-hub
Icon=$dest/lan-party-hub.png
Terminal=false
Categories=Game;
DESK
update-desktop-database "$apps" >/dev/null 2>&1 || true

echo "Installed to $dest"
echo "Menu entry: LAN Party Host (players open http://<this PC>:$web_port)"

# Bazzite runs firewalld, which blocks incoming connections by default.
if [ "$1" != "--no-firewall" ] && command -v firewall-cmd >/dev/null 2>&1; then
    zones=$(firewall-cmd --get-active-zones 2>/dev/null | grep -v '^[[:space:]]')
    [ -z "$zones" ] && zones=$(firewall-cmd --get-default-zone 2>/dev/null)
    cmds=()
    for z in $zones; do
        for p in $web_port $game_web_ports; do
            firewall-cmd --zone="$z" --query-port=$p/tcp >/dev/null 2>&1 \
                || cmds+=("sudo firewall-cmd --permanent --zone=$z --add-port=$p/tcp")
        done
        for p in $udp_ports; do
            firewall-cmd --zone="$z" --query-port=$p/udp >/dev/null 2>&1 \
                || cmds+=("sudo firewall-cmd --permanent --zone=$z --add-port=$p/udp")
        done
    done
    if [ ${#cmds[@]} -eq 0 ]; then
        echo "Firewall: TCP $web_port, ${game_web_ports// /, } and UDP ${udp_ports// /, } are already open."
    else
        echo
        echo "To host, this PC must accept TCP $web_port, ${game_web_ports// /, } and UDP ${udp_ports// /, } from the LAN."
        read -r -p "Open them in the firewall now? You will be asked for your password. [Y/n] " answer
        if [ -z "$answer" ] || [ "${answer,,}" = "y" ]; then
            ok=1
            for c in "${cmds[@]}"; do $c || ok=0; done
            sudo firewall-cmd --reload && [ $ok = 1 ] && echo "Firewall: opened in zone(s): $zones"
        else
            echo "Skipped. Later run:"
            for c in "${cmds[@]}"; do echo "  $c"; done
            echo "  sudo firewall-cmd --reload"
        fi
    fi
fi
